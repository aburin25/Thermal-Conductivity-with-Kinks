function y=OmMax(A, B, ph1)
    fun=@(x) vgroup(x, A, B, ph1); 
    zz=fzero(fun, 1); 
    tt=RegSpectrq(zz, A, B, ph1, 0);
    y=tt.om;
end