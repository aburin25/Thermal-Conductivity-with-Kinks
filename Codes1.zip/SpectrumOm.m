function y=SpectrumOm(A, B, ph1, om)
    Pol(1)=-8*A*B*sin(ph1)^2;
    Pol(2)=-8*A*B*sin(ph1)^2+4*om^2*B; 
    Pol(3)=8*A*B*sin(ph1)^2+2*A*om^2*cos(2*ph1); 
    Pol(4)=8*A*B*sin(ph1)^2-4*om^2*B-2*A*om^2+om^4; 
    Roots=roots(Pol); 
    [~, ord]=sort(abs(Roots)); 
    Roots=Roots(ord); 
    q1=acos(Roots(2));
    q2=acos(Roots(1));
    q=[q1 -q1 q2 -q2]; 
    if Roots(3) > 0 
        Gam=log(Roots(3)+sqrt(Roots(3)^2-1)); 
    else
        Gam=log(abs(Roots(3))+sqrt(Roots(3)^2-1))+1i*pi; 
    end
    Bl1=-om^2+2*A*(1-cos(q))*cos(ph1)^2+2*B*(1-cos(2*q)); 
    Bl2=1i*sin(q)*sin(2*ph1)*A;
    Rats=[ones(4, 1) (Bl2./Bl1)'];
    Norm=sqrt(abs(Rats(:, 1)).^2+abs(Rats(:, 2)).^2); 
    y.Vsq=[Rats(:, 1)./Norm Rats(:, 2)./Norm]; 
    y.Wv=q; 
    y.Gam=Gam; 
    y.ImExp=[Roots(2)+1i*sqrt(1-Roots(2)^2) Roots(2)-1i*sqrt(1-Roots(2)^2) Roots(1)+1i*sqrt(1-Roots(1)^2) Roots(1)-1i*sqrt(1-Roots(1)^2)];
    y.ReExp=[Roots(3)+sqrt(Roots(3)^2-1) Roots(3)-sqrt(Roots(3)^2-1)]; 

end