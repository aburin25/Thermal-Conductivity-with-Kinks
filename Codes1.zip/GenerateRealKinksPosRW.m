function y=GenerateRealKinksPosRW(Set, Phis, ph)
    Sums=[0;cumsum(Set)];
    n=size(Set, 1);
    X=zeros(1, Sums(end)); Y=X; 
    X0=0; Y0=0; %phc=Phis(1);   
    Phis1=[Phis; 0]; 
    for ii=1:n
        phc=Phis1(ii);
        In=Sums(ii)+1; Fin=Sums(ii+1);  
        XX0=0:(Fin-In); 
        YY0=((-1).^(In:Fin)-(-1)^In)*tan(ph)/2; 
        XX=XX0*cos(phc)-YY0*sin(phc); 
        YY=XX0*sin(phc)+YY0*cos(phc); 
        X(In:Fin)=X0+XX; 
        Y(In:Fin)=Y0+YY;       
        dX=1; dY=-tan(ph)*(-1)^Fin; 
        X0=X(Fin)+dX*cos(Phis1(ii+1))-dY*sin(Phis1(ii+1)); 
        Y0=Y(Fin)+dX*sin(Phis1(ii+1))+dY*cos(Phis1(ii+1)); 
    end
    y.Coord=[X; Y]; 
end
%Tst=0; while Tst==0; y=GenerateRealKinksRW(20, 4, ph); yz=GenerateRealKinksPosRW(y.Set, y.Phis, ph, ph); if abs(yz.Coord(2, end)) < 10^(-10); Tst=1; end; end; plot(yz.Coord(1, :), yz.Coord(2, :))
