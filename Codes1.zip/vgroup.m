function y=vgroup(q, A, B, ph1)
    z=RegSpectrq(q, A, B, ph1, 0);
    y=z.vg; 
end