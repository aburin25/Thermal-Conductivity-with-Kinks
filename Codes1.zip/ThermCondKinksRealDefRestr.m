function y=ThermCondKinksRealDefRestr(l, k, A, B, ph, ph1, n1, n2, xi, Ym)
% l - average distance between kinks, k number of kinks should be divisor
% of 4
rng("shuffle");
fname1=['ThCondRealDefRestrl' num2str(l) 'k' num2str(k) 'A' num2str(A) 'B' num2str(B) 'ph' num2str(ph) 'ph1' num2str(ph1) 'xi' num2str(xi) 'Ym' num2str(Ym) '.txt']; 
for ii=n1:n2
    yzz=GenerateRestrKinksCoord(ph, ph1, Ym, l, k); 
%    yzz=GenerateRealKinksCoord(k, l, ph, ph1);
%    yzz=GenerateKinks(N, k, ph, ph1);
    yz=BlocksCoordDef(yzz.CoordExt, A, B, ph, xi); 
    Om=OmMax(A, B, ph);
    II=integral(@(x) TransmVect(yz.Hin, yz.Vl, yz.Vr, A, B, ph, x), 10^(-6), Om, 'RelTol', 2.5e-3,'AbsTol', 10^(-3)/(k*l));%, 'RelTol',1e-2,'AbsTol',1e-5);
    dlmwrite(fname1, II*k*l, '-append', 'precision', 14);
%    fname2=['ThCondDefN' num2str(N) 'k' num2str(k) 'A' num2str(A) 'B' num2str(B) 'ph' num2str(ph) 'ph1' num2str(ph1) 'SetNum' num2str(ii) 'xi' num2str(xi) '.txt']; 
%    dlmwrite(fname2, yzz.CoordExt, 'precision', 14); 
    %fname3=['Transm_A' num2str(A) 'B' num2str(B) 'ph' num2str(ph) 'N' num2str(N) 'k' num2str(k) 'ph1' num2str(ph1) '.txt'];
    %FrTrDat=dlmread(fname3); 
    %disp(size(FrTrDat)); 
    %[~, ord]=sort(FrTrDat(:, 1)); 
    %delete(fname3); 
    %FrTrDat=FrTrDat(ord, :); 
    %fname4=['TransmDef_A' num2str(A) 'B' num2str(B) 'ph' num2str(ph) 'N' num2str(N) 'k' num2str(k) 'ph1' num2str(ph1) 'SetNum' num2str(ii) 'xi' num2str(xi) '.txt'];
    %dlmwrite(fname4, FrTrDat, 'precision', 14); 
    disp(ii); 
end
kap=dlmread(fname1); 
k=mean(kap); 
Dk=std(kap)/(mean(kap)*sqrt(max(size(kap)))); 
y.k=k;
y.Dk=Dk; 
end

% Check carefully force constant and mass defects. What determines
% transport? Try more kinks