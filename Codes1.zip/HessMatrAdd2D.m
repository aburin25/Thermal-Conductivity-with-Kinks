function y=HessMatrAdd2D(r1, r2, A)
    Diff=(r1-r2)/norm(r1-r2); 
    HM=zeros(4, 4); 
    HM(1, 3)=-Diff(1)^2; HM(1, 1)=HM(1, 1)+Diff(1)^2; 
    HM(3, 1)=-Diff(1)^2; HM(3, 3)=HM(3, 3)+Diff(1)^2; 
    HM(2, 4)=-Diff(2)^2; HM(2, 2)=HM(2, 2)+Diff(2)^2; 
    HM(4, 2)=-Diff(2)^2; HM(4, 4)=HM(4, 4)+Diff(2)^2; 
    HM(1, 4)=-Diff(1)*Diff(2); HM(1, 2)=HM(1, 2)+Diff(1)*Diff(2); 
    HM(4, 1)=-Diff(1)*Diff(2); HM(4, 3)=HM(4, 3)+Diff(1)*Diff(2); 
    HM(2, 3)=-Diff(1)*Diff(2); HM(2, 1)=HM(2, 1)+Diff(1)*Diff(2); 
    HM(3, 2)=-Diff(1)*Diff(2); HM(3, 4)=HM(3, 4)+Diff(1)*Diff(2); 
    y=A*HM; 
end