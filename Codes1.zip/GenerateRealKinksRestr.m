function y=GenerateRealKinksRestr(ph, ph1, Ymax, l, k)
ll=1+poissrnd(l-1, 1, 1);
Set=ll; 
phics=0; 
XX=0:(ll-1); 
YY=tan(ph)*(1+(-1).^(1:ll))/2;
Coord=[XX; YY]; 
for ii=1:k
    z=GenerateNext(Coord, phics, ph, ph1, Ymax, l, Set);
    Coord=z.Coord; 
    phics=z.phics; 
    Set=z.Set; 
end
y=z; 
end