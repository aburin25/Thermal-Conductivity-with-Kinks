function y=Gs(n1, n2, H, om)
% n1, n2 - vectors of nunbers to define Green function in between
% солутион бы elimination 
% x = A\b
nn1=max(size(n1));
nn2=max(size(n2));
Gs=zeros(nn1, nn2); 
N=size(H, 1); 
for ii=1:nn2
    V=zeros(N, 1);
    V(n2(ii))=1; 
%    disp(size(V)); 
%    disp(size(H)); 
%    disp(om); 
    Res=(om^2*eye(N, N)-H)\V; 
    Gs(:, ii)=Res(n1); 
end
y=Gs;
end 