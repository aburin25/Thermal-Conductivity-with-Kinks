function [y, Tst, Trl, Trt]=Transmission(om, Vl, Vr, H, A, B, ph)
Sigm=SelfEnerg(om, Vl, Vr, H); 
N=size(H, 1);
[Trl, y1]=GetTrsl(N, A, B, ph, om, Sigm); 
[Trt, y2]=GetTrst(N, A, B, ph, om, Sigm); 
Trl=Trl;
Trt=Trt;
y=Trl+Trt;
if y>2
    disp(y);
end
Tst=[y1.Check y2.Check]; 
if (y1.Check>1.1)||(y2.Check>1.1)
    disp('Normalization fails');
end
end
