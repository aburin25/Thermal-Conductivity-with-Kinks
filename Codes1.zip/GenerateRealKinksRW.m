function y=GenerateRealKinksRW(k, l, ph1)
% Create directed set of kinks, no u turns 
% k number of kinks, must be even and divisible by 4
% l>2 mean kink length 
% total length must be exactly kl
%rng("shuffle");
Tst=0; 
while Tst==0
    Set = 1+poissrnd(l-1, k, 1);
    if sum(Set)< k*l
        Sums=cumsum(Set);
        Signs=(-1).^Sums; 
        Phis=[0; cumsum(Signs)*ph1]; 
  %      disp(sum((-1).^(Sums(Ser)).*Set2))
        if Phis(end)==0
 %           disp(size(Set));
 %           disp(size(Phis)); 
  %          if sum(Set.*sin(Phis(1:(end-1))))==0
            Tst=1;
  %          end
        end
    end
end
y.Set=[Set; k*l-sum(Set)+1];
y.Phis=Phis; 
SetExt=y.Set; 
SetExt(1)=SetExt(1)+2; SetExt(end)=SetExt(end)+2; 
y.SetExt=SetExt; 
% for ii=1:k
% 
% end
end
