function y=Hessian2DOpDef(Coord, A, B, xi)
% xi defect in force constant xi*B in the position of kink
    if size(Coord, 1)==2
        Coord=Coord';
    end
    N=size(Coord, 1);
    H=zeros(2*N, 2*N);
    for ii=1:(N-1)
        %Hessian for nearest neighbors 
        r1=Coord(ii, :); 
        r2=Coord(ii+1, :); 
        Hl=HessMatrAdd2D(r1, r2, A);
        H([ii N+ii ii+1 N+ii+1], [ii N+ii ii+1 N+ii+1])=H([ii N+ii ii+1 N+ii+1], [ii N+ii ii+1 N+ii+1])+Hl; 
        if ii<N-1
            r3=Coord(ii+2, :);
            if norm(r1-r3) ~= 2
                Hl=HessMatrAdd2D(r1, r3, xi*B);
            else
                Hl=HessMatrAdd2D(r1, r3, B);
            end
            H([ii N+ii  ii+2  N+ii+2], [ii N+ii  ii+2  N+ii+2])=H([ii N+ii  ii+2  N+ii+2], [ii N+ii  ii+2  N+ii+2])+Hl; 
        end
    end
    y.H0=H; 
end