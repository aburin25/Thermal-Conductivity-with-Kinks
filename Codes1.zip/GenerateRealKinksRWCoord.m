function y=GenerateRealKinksRWCoord(k, l, ph, ph1)
Tst=0; 
while Tst==0 
    yzz=GenerateRealKinksRW(k, l, ph1); 
    yz=GenerateRealKinksPosRW(yzz.SetExt, yzz.Phis, ph); 
    if abs(yz.Coord(2, end)) < 10^(-10) 
        Tst=1; 
    end 
end 
y.CoordExt=yz.Coord; 
end
%Tst=0; while Tst==0; y=GenerateRealKinksRW(20, 4, ph); yz=GenerateRealKinksPosRW(y.Set, y.Phis, ph, ph); if abs(yz.Coord(2, end)) < 10^(-10); Tst=1; end; end; plot(yz.Coord(1, :), yz.Coord(2, :))
