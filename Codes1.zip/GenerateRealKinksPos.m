function y=GenerateRealKinksPos(Set, ph, ph1)
    if size(Set, 1)<size(Set, 2)
        Set=Set';
    end
    Sums=[0;cumsum(Set)];
    n=size(Set, 1);
    X=zeros(1, Sums(end)); Y=X; 
    X0=0; Y0=0; phc=0;   
    for ii=1:n
        In=Sums(ii)+1; Fin=Sums(ii+1);  
        XX0=0:(Fin-In); 
        YY0=((-1).^(In:Fin)-(-1)^In)*tan(ph)/2; 
        XX=XX0*cos(phc)-YY0*sin(phc); 
        YY=XX0*sin(phc)+YY0*cos(phc); 
        X(In:Fin)=X0+XX; 
        Y(In:Fin)=Y0+YY;
        if phc~=0
            phc=0;
        else
            phc=ph1*(-1)^Fin; 
        end
        dX=1; dY=-tan(ph)*(-1)^Fin; 
        X0=X(Fin)+dX*cos(phc)-dY*sin(phc); 
        Y0=Y(Fin)+dX*sin(phc)+dY*cos(phc); 
    end
    y.Coord=[X; Y]; 
end