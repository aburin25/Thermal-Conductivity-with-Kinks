function y=TransmVect(H, Vl, Vr, A, B, ph, Om)
Sz=size(Om); 
Ts=zeros(Sz); 
% disp(Sz); 
%fname=['Transm_A' num2str(A) 'B' num2str(B) 'ph' num2str(ph) 'N' num2str(N) 'k' num2str(k) 'ph1' num2str(ph1) '.txt'];
parfor ii=1:Sz(2)
        om=Om(1, ii); 
        Ts(1, ii)=Transmission(om, Vl, Vr, H, A, B, ph);
     
end
%   disp(mean(Ts));
y=Ts;
end