function [Trt, y]=GetTrst(N, A, B, ph, om, Sigm)
%y=TrMatrPartstr(H, Vl, Vr, A, B, ph, om)
% Check0x=-om^2*v(1)+A*cos(ph)^2*(2*v(1)-v1(1)-vm1(1))+B*(2*v(1)-v2(1)-vm2(1))-A*sin(2*ph)*(v1(2)-vm1(2))/2; 
% Check0y=-om^2*v(2)+A*sin(ph)^2*(2*v(2)-v1(2)-vm1(2))-A*sin(2*ph)*(v1(1)-vm1(1))/2;
% Check1x=-om^2*u11+A*cos(ph)^2*(2*u11-u21-u01)+B*(2*u11-u31-u0m11)+A*sin(2*ph)*(um22-u0m02)/2; 
% v1=Vectntr(A, B, ph, om, n, num)
%N=size(H, 1);
u11=Vectntr(A, B, ph, om, 1, 1, N/2); u12=Vectntr(A, B, ph, om, 1, 2, N/2); 
u21=Vectntr(A, B, ph, om, 2, 1, N/2); u22=Vectntr(A, B, ph, om, 2, 2, N/2); 
u31=Vectntr(A, B, ph, om, 3, 1, N/2); u32=Vectntr(A, B, ph, om, 3, 2, N/2); 
u41=Vectntr(A, B, ph, om, 4, 1, N/2); %u42=Vectntr(A, B, ph, om, 4, 2); 
un11=Vectntr(A, B, ph, om, -1, 1, N/2); un12=Vectntr(A, B, ph, om, -1, 2, N/2); 
un21=Vectntr(A, B, ph, om, -2, 1, N/2); un22=Vectntr(A, B, ph, om, -2, 2, N/2); 
un31=Vectntr(A, B, ph, om, -3, 1, N/2); un32=Vectntr(A, B, ph, om, -3, 2, N/2); 
un41=Vectntr(A, B, ph, om, -4, 1, N/2); %un42=Vectntr(A, B, ph, om, -4, 2); 
%u51=Vectntr(A, B, ph, om, 5, 1); u52=Vectntr(A, B, ph, om, 5, 2);
%Sites=[3:(2+N) (N+7):(2*N+6)];
%Sitesl=[1 2 N+6]; Sitesr=[N+3 N+4 2*N+7];
%SitesInl=[3 4 N+7 N+8]; SitesInr=[N+1 N+2 2*N+5 2*N+6];
Ul=[un21; un11; un12]; Ur=[u11; u21; u12]; 
%Sigm=SelfEnerg(om, Vl, Vr, H); 
Deltal=Sigm.Mll*Ul+Sigm.Mlr*Ur; 
Deltar=Sigm.Mrl*Ul+Sigm.Mrr*Ur;
Eqn21=-om^2*un21+A*cos(ph)^2*(2*un21-un31-un11)+B*(2*un21-un41)+A*sin(2*ph)*(un32-un12)/2+Deltal(1, :);   % -2 0
Eqn11=-om^2*un11+A*cos(ph)^2*(2*un11-un21)+B*(2*un11-un31)-A*sin(2*ph)*(un22)/2+Deltal(2, :);
Eqn12=-om^2*un12+A*sin(ph)^2*(2*un12-un22)-A*sin(2*ph)*un21/2+Deltal(3, :);
Eq21=-om^2*u21+A*cos(ph)^2*(2*u21-u31-u11)+B*(2*u21-u41)-A*sin(2*ph)*(u32-u12)/2+Deltar(2, :);
Eq11=-om^2*u11+A*cos(ph)^2*(2*u11-u21)+B*(2*u11-u31)+A*sin(2*ph)*(u22)/2+Deltar(1, :);
Eq12=-om^2*u12+A*sin(ph)^2*(2*u12-u22)+A*sin(2*ph)*u21/2+Deltar(3, :);
M=[Eqn21; Eqn11; Eqn12; Eq21; Eq11; Eq12]; 
y.M=M; 
%disp(size(M)); 
%trs=-M(:, 2:end)^(-1)*M(:, 1); 
trs=-M(:, 2:end)\M(:, 1); 
%disp(min(abs(eig(M(:, 2:end))))); 
Sp1=SpectrumOm(A, B, ph, om); 
q=Sp1.Wv; 
Spq1=RegSpectrq(q(1), A, B, ph, 0); 
v1=abs(Spq1.vg);
Spq2=RegSpectrq(q(3), A, B, ph, 0); 
v2=abs(Spq2.vg);
TRs=abs(trs.^2); 
TRs(1)=TRs(1)*v1/v2; 
TRs(4)=TRs(4)*v1/v2;
y.TR=[TRs(1); TRs(2); TRs(4); TRs(5)]; 
y.trs=trs;
Trt=TRs(4)+TRs(5);
y.Check=sum(y.TR)-1; 
end