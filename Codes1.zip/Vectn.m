function y=Vectn(A, B, ph, om, n, num, N)
% num=1 or 2 for longitudinal or transverse coordinate
% n=-2, -1, ...2 number of atom
z=SpectrumOm(A, B, ph, om); 
q=z.Wv; %[q1 -q1 q2 -q2]
Gam=z.Gam; 
Vv=zeros(7, 1); % inc, refl l, refl t, ev, tr l, tr t, ev
if n<0
    yz1=RegSpectrq(q(1), A, B, ph, n);
    yzr1=RegSpectrq(-q(1), A, B, ph, n);
    yzr2=RegSpectrq(q(3), A, B, ph, n);
    if real(Gam)>0 
        yzrev=RegSpectrq(-1i*Gam, A, B, ph, n); %exp(-inGam)
    else
        yzrev=RegSpectrq(1i*Gam, A, B, ph, n);
    end
    Vv=[yz1.V(num) yzr1.V(num) yzr2.V(num) yzrev.V(num) 0 0 0]; 
else
    yzt1=RegSpectrq(q(1), A, B, ph, n);
    yzt2=RegSpectrq(q(4), A, B, ph, n);
    if real(Gam)>0 
        yztev=RegSpectrq(1i*Gam, A, B, ph, n);
    else
        yztev=RegSpectrq(-1i*Gam, A, B, ph, n);
    end
    Vv=[0 0 0 0 exp(1i*q(1)*(N-1))*yzt1.V(num) exp(1i*q(4)*(N-1))*yzt2.V(num) yztev.V(num)]; 
end
y=Vv;
end
