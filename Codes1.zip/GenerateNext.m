function y=GenerateNext(Coord, phics, ph, ph1, Ymax, l, Set)
N=size(Coord, 2); 
if phics(end)~=0
    y.phics=[phics 0];
    ll=2+2*poissrnd((l-2)/2, 1, 1);
    XX=1:ll; 
    YY=tan(ph)*((-1).^(XX+N)-(-1)^N)/2;
    X=XX+Coord(1, N); 
    Y=YY+Coord(2, N);
else
    Tst=1;
    phic=(-1)^N*ph1; 
    y.phics=[phics phic]; 
    while Tst==1
        ll=1+2*poissrnd((l-1)/2, 1, 1);
        XX0=1:ll; 
        YY0=tan(ph)*((-1).^(XX0+N)-(-1)^N)/2;
        XX=XX0*cos(phic)-YY0*sin(phic);
        YY=XX0*sin(phic)+YY0*cos(phic); 
        X=XX+Coord(1, N); 
        Y=YY+Coord(2, N);
        if max(abs(Y-1/2))<Ymax
            Tst=0;
        end
    end
end
y.Coord=[Coord(1, :) X; Coord(2, :) Y];  
y.Set=[Set ll]; 
% disp(y.phics); 
% disp(y.Set);
% disp(y.Coord); 
end