function y=SelfEnerg(om, Vl, Vr, H)
    N=size(H, 1)/2; 
    n1=[1 2 N+1 N+2]; 
    n2=[N-1 N 2*N-1 2*N];
    y.Mll=Vl*Gs(n1, n1, H, om)*Vl'; 
    y.Mlr=Vl*Gs(n1, n2, H, om)*Vr'; 
    y.Mrr=Vr*Gs(n2, n2, H, om)*Vr'; 
    y.Mrl=Vr*Gs(n2, n1, H, om)*Vl'; 
end
%Gs(n1, n2, H, om)
% Sitesl=[1 2 N+7]; Sitesr=[N+4 N+5 2*N+9];
% SitesInl=[3 4 N+8 N+9]; SitesInr=[N+2 N+3 2*N+7 2*N+8];