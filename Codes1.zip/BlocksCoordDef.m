function y=BlocksCoordDef(Coordin, A, B, ph, xi)
% Coord - Nx2 coordinates of defect domain starts at 0, 0 ends at x(N), 0,
% N - odd 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 10/10
% xm2=-1; ym2=0; xm1=-1/2; ym1=tan(ph)/2;
% x2=Coordin(end, 1)+1; y2=0; x1=Coordin(end, 1)+1/2; y1=tan(ph)/2;
if size(Coordin, 1)==2
    Coordin=Coordin';
end
xm2=-2; ym2=0; xm1=-1; ym1=tan(ph);
x2=Coordin(end, 1)+2; y2=Coordin(end, 2); x1=Coordin(end, 1)+1; y1=Coordin(end, 2)+tan(ph);
Coord=[xm2 ym2; xm1 ym1; Coordin; x1 y1; x2 y2]; 
N=size(Coordin, 1)-1; 
% end 10/10
%z=GenerateKinks(N/4, k, ph, ph1);

%Coord=z.CoordExt;
% Generate Hessian, extract blocks
yz=Hessian2DOpDef(Coord, A, B, xi);
% Central block 
H=yz.H0; 
Sites=[3:(3+N) (N+8):(2*N+8)];
Sitesl=[1 2 N+7]; Sitesr=[N+4 N+5 2*N+9];
SitesInl=[3 4 N+8 N+9]; SitesInr=[N+2 N+3 2*N+7 2*N+8];
SitesInTot=[3:(N+3) (N+8):(2*N+8)];
y.Hin=H(Sites, Sites); 
y.Vl=H(Sitesl, SitesInl); 
y.Vlt=H(Sitesl, SitesInTot);
y.Vr=H(Sitesr, SitesInr);
y.Vrt=H(Sitesr, SitesInTot);
y.Ht=H; 
y.Coord=Coord; 
end
% tests 
% Tst=-om^2*u42+A*sin(ph1)^2*(2*u42-u32-u52)-A*sin(2*ph1)*(u51-u31)/2
