function y=GenerateRestrKinksCoord(ph, ph1, Ymax, l, k)
Tst=0; 
while Tst==0
    yz=GenerateRealKinksRestr(ph, ph1, Ymax, l, k);
    Summ=sum(yz.Set(1:(end-1))); 
    N=size(yz.Coord, 2); 
    if (Summ < l*k)
        nn=1+(1-(-1)^Summ)/2; 
%        disp(norm(yz.Coord(2, Summ+1)-yz.Coord(2, nn)));
        if norm(yz.Coord(2, Summ+1)-yz.Coord(2, nn))<10^(-10)
            Tst=1; 
        end
    end
end
Set=yz.Set; 
Set(1)=Set(1)+2; 
if rem(N, 2)==0
    Set(end)=Set(end)+3;
else
    Set(end)=Set(end)+2;
end
y.yz=yz;
y.SetExt=Set;
Str=GenerateRealKinksPos(Set, ph, ph1); 
y.CoordExt=Str.Coord; 
end

% REPRESENTATIVE SKECTH OF STRUCTURE
% yz=GenerateRestrKinksCoord(ph, ph, Ymax, l, 16); 
% plot(yz.CoordExt(1, :), yz.CoordExt(2, :)); axis equal;