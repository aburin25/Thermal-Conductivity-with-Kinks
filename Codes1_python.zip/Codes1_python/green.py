import numpy as np

def Gs(n1,n2,H,om):
    n1=np.asarray(n1,int); n2=np.asarray(n2,int); out=np.zeros((len(n1),len(n2)),dtype=complex); M=om**2*np.eye(H.shape[0])-H
    for j,idx in enumerate(n2): out[:,j]=np.linalg.solve(M,np.eye(H.shape[0])[:,idx])[n1]
    return out

def self_energ(om,Vl,Vr,H):
    N=H.shape[0]//2; n1=[0,1,N,N+1]; n2=[N-2,N-1,2*N-2,2*N-1]
    return {'Mll':Vl@Gs(n1,n1,H,om)@Vl.T,'Mlr':Vl@Gs(n1,n2,H,om)@Vr.T,'Mrr':Vr@Gs(n2,n2,H,om)@Vr.T,'Mrl':Vr@Gs(n2,n1,H,om)@Vl.T}
