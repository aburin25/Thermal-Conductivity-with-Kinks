import numpy as np
from .green import self_energ
from .vectors import vectn,vectntr
from .spectrum import spectrum_om,reg_spectrq

def _get_tr(N,A,B,ph,om,Sigm,transverse=False):
    fn=vectntr if transverse else vectn
    u11=fn(A,B,ph,om,1,1,N/2); u12=fn(A,B,ph,om,1,2,N/2); u21=fn(A,B,ph,om,2,1,N/2); u22=fn(A,B,ph,om,2,2,N/2); u31=fn(A,B,ph,om,3,1,N/2); u32=fn(A,B,ph,om,3,2,N/2); u41=fn(A,B,ph,om,4,1,N/2)
    un11=fn(A,B,ph,om,-1,1,N/2); un12=fn(A,B,ph,om,-1,2,N/2); un21=fn(A,B,ph,om,-2,1,N/2); un22=fn(A,B,ph,om,-2,2,N/2); un31=fn(A,B,ph,om,-3,1,N/2); un32=fn(A,B,ph,om,-3,2,N/2); un41=fn(A,B,ph,om,-4,1,N/2)
    Ul=np.array([un21,un11,un12]); Ur=np.array([u11,u21,u12]); Dl=Sigm['Mll']@Ul+Sigm['Mlr']@Ur; Dr=Sigm['Mrl']@Ul+Sigm['Mrr']@Ur
    if not transverse:
        rows=[-om**2*un21+A*np.cos(ph)**2*(2*un21-un31-un11)+B*(2*un21-un41)+A*np.sin(2*ph)*(un32-un12)/2+Dl[0],-om**2*un11+A*np.cos(ph)**2*(2*un11-un21)+B*(2*un11-un31)-A*np.sin(2*ph)*un22/2+Dl[1],-om**2*un12+A*np.sin(ph)**2*(2*un12-un22)-A*np.sin(2*ph)*un21/2+Dl[2],-om**2*u21+A*np.cos(ph)**2*(2*u21-u31-u11)+B*(2*u21-u41)-A*np.sin(2*ph)*(u32-u12)/2+Dr[1],-om**2*u11+A*np.cos(ph)**2*(2*u11-u21)+B*(2*u11-u31)+A*np.sin(2*ph)*u22/2+Dr[0],-om**2*u12+A*np.sin(ph)**2*(2*u12-u22)+A*np.sin(2*ph)*u21/2+Dr[2]]
    else:
        rows=[-om**2*un21+A*np.cos(ph)**2*(2*un21-un31-un11)+B*(2*un21-un41)+A*np.sin(2*ph)*(un32-un12)/2+Dl[0],-om**2*un11+A*np.cos(ph)**2*(2*un11-un21)+B*(2*un11-un31)-A*np.sin(2*ph)*un22/2+Dl[1],-om**2*un12+A*np.sin(ph)**2*(2*un12-un22)-A*np.sin(2*ph)*un21/2+Dl[2],-om**2*u21+A*np.cos(ph)**2*(2*u21-u31-u11)+B*(2*u21-u41)-A*np.sin(2*ph)*(u32-u12)/2+Dr[1],-om**2*u11+A*np.cos(ph)**2*(2*u11-u21)+B*(2*u11-u31)+A*np.sin(2*ph)*u22/2+Dr[0],-om**2*u12+A*np.sin(ph)**2*(2*u12-u22)+A*np.sin(2*ph)*u21/2+Dr[2]]
    M=np.vstack(rows); trs=np.linalg.solve(M[:,1:],-M[:,0]); q=spectrum_om(A,B,ph,om)['Wv']; v1=abs(reg_spectrq(q[0],A,B,ph,0)['vg']); v2=abs(reg_spectrq(q[2],A,B,ph,0)['vg']); TRs=np.abs(trs)**2
    if not transverse: TRs[[1,4]]*=v2/v1; tr=TRs[3]+TRs[4]; TR=np.array([TRs[0],TRs[1],TRs[3],TRs[4]])
    else: TRs[[0,3]]*=v1/v2; tr=TRs[3]+TRs[4]; TR=np.array([TRs[0],TRs[1],TRs[3],TRs[4]])
    return tr,{'M':M,'TR':TR,'Check':TR.sum()-1,'trs':trs}

def transmission(om,Vl,Vr,H,A,B,ph):
    Sigm=self_energ(om,Vl,Vr,H); Trl,y1=_get_tr(H.shape[0],A,B,ph,om,Sigm,False); Trt,y2=_get_tr(H.shape[0],A,B,ph,om,Sigm,True); y=Trl+Trt
    return y,y1['Check'],Trl,Trt

def transm_vect(H,Vl,Vr,A,B,ph,Om):
    Om=np.atleast_1d(Om); return np.array([transmission(float(x),Vl,Vr,H,A,B,ph)[0] for x in Om])
