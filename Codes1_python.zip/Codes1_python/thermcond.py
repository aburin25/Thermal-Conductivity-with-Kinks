import numpy as np
from scipy.integrate import quad
from .kinks import generate_restr_kinks_coord,generate_real_kinks_rw_coord
from .hessian import blocks_coord_def
from .spectrum import om_max
from .transmission import transmission

def _integrate(H,Vl,Vr,A,B,ph,upper,abstol):
    val,err=quad(lambda x: float(np.real(transmission(x,Vl,Vr,H,A,B,ph)[0])),1e-6,upper,epsrel=2.5e-3,epsabs=abstol,limit=200)
    return val

def therm_cond_kinks_real_def_restr(l,k,A,B,ph,ph1,n1,n2,xi,Ym,seed=None):
    rng=np.random.default_rng(seed); kap=[]
    for _ in range(n1,n2+1):
        z=generate_restr_kinks_coord(ph,ph1,Ym,l,k,rng); yz=blocks_coord_def(z['CoordExt'],A,B,ph,xi); kap.append(_integrate(yz['Hin'],yz['Vl'],yz['Vr'],A,B,ph,om_max(A,B,ph),1e-3/(k*l))*k*l)
    kap=np.asarray(kap); return {'k':kap.mean(),'Dk':kap.std(ddof=1)/(kap.mean()*np.sqrt(len(kap))) if len(kap)>1 else np.nan,'samples':kap}

def therm_cond_kinks_real_rw_def(l,k,A,B,ph,ph1,n1,n2,xi,seed=None):
    rng=np.random.default_rng(seed); kap=[]
    for _ in range(n1,n2+1):
        z=generate_real_kinks_rw_coord(k,l,ph,ph1,rng); yz=blocks_coord_def(z['CoordExt'],A,B,ph,xi); kap.append(_integrate(yz['Hin'],yz['Vl'],yz['Vr'],A,B,ph,om_max(A,B,ph),1e-6)*k*l)
    kap=np.asarray(kap); return {'k':kap.mean(),'Dk':kap.std(ddof=1)/(kap.mean()*np.sqrt(len(kap))) if len(kap)>1 else np.nan,'samples':kap}
