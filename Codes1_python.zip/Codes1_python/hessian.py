import numpy as np

def hess_matr_add_2d(r1, r2, A):
    r1=np.asarray(r1,float); r2=np.asarray(r2,float)
    diff=(r1-r2)/np.linalg.norm(r1-r2)
    dx,dy=diff
    HM=np.zeros((4,4),float)
    HM[0,2]=-dx**2; HM[0,0]+=dx**2
    HM[2,0]=-dx**2; HM[2,2]+=dx**2
    HM[1,3]=-dy**2; HM[1,1]+=dy**2
    HM[3,1]=-dy**2; HM[3,3]+=dy**2
    HM[0,3]=-dx*dy; HM[0,1]+=dx*dy
    HM[3,0]=-dx*dy; HM[3,2]+=dx*dy
    HM[1,2]=-dx*dy; HM[1,0]+=dx*dy
    HM[2,1]=-dx*dy; HM[2,3]+=dx*dy
    return A*HM

def hessian_2d_op_def(Coord,A,B,xi):
    C=np.asarray(Coord,float)
    if C.shape[0]==2: C=C.T
    N=len(C); H=np.zeros((2*N,2*N),float)
    for ii in range(N-1):
        r1,r2=C[ii],C[ii+1]
        idx=[ii,N+ii,ii+1,N+ii+1]
        H[np.ix_(idx,idx)] += hess_matr_add_2d(r1,r2,A)
        if ii<N-2:
            r3=C[ii+2]; idx=[ii,N+ii,ii+2,N+ii+2]
            kk=xi*B if not np.isclose(np.linalg.norm(r1-r3),2) else B
            H[np.ix_(idx,idx)] += hess_matr_add_2d(r1,r3,kk)
    return {'H0':H}

def blocks_coord_def(Coordin,A,B,ph,xi):
    C=np.asarray(Coordin,float)
    if C.shape[0]==2: C=C.T
    xm2,ym2=-2.,0.; xm1,ym1=-1.,np.tan(ph)
    x2=C[-1,0]+2; y2=C[-1,1]; x1=C[-1,0]+1; y1=C[-1,1]+np.tan(ph)
    Coord=np.vstack(([xm2,ym2],[xm1,ym1],C,[x1,y1],[x2,y2]))
    N=len(C)-1
    H=hessian_2d_op_def(Coord,A,B,xi)['H0']
    sites=list(range(2,3+N))+list(range(N+7,2*N+8))
    sitesl=[0,1,N+6]; sitesr=[N+3,N+4,2*N+8]
    sitesinl=[2,3,N+7,N+8]; sitesinr=[N+1,N+2,2*N+6,2*N+7]
    sitestot=list(range(2,N+4))+list(range(N+7,2*N+9))
    return {'Hin':H[np.ix_(sites,sites)],'Vl':H[np.ix_(sitesl,sitesinl)],'Vlt':H[np.ix_(sitesl,sitestot)],'Vr':H[np.ix_(sitesr,sitesinr)],'Vrt':H[np.ix_(sitesr,sitestot)],'Ht':H,'Coord':Coord}
