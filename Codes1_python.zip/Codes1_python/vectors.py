import numpy as np
from .spectrum import spectrum_om,reg_spectrq

def vectn(A,B,ph,om,n,num,N):
    z=spectrum_om(A,B,ph,om); q=z['Wv']; Gam=z['Gam']; Vv=np.zeros(7,dtype=complex)
    if n<0:
        yz1=reg_spectrq(q[0],A,B,ph,n); yzr1=reg_spectrq(-q[0],A,B,ph,n); yzr2=reg_spectrq(q[2],A,B,ph,n)
        yzrev=reg_spectrq(-1j*Gam if np.real(Gam)>0 else 1j*Gam,A,B,ph,n)
        Vv[:4]=[yz1['V'][num-1],yzr1['V'][num-1],yzr2['V'][num-1],yzrev['V'][num-1]]
    else:
        yzt1=reg_spectrq(q[0],A,B,ph,n); yzt2=reg_spectrq(q[3],A,B,ph,n)
        yztev=reg_spectrq(1j*Gam if np.real(Gam)>0 else -1j*Gam,A,B,ph,n)
        Vv[4:]=[np.exp(1j*q[0]*(N-1))*yzt1['V'][num-1],np.exp(1j*q[3]*(N-1))*yzt2['V'][num-1],yztev['V'][num-1]]
    return Vv

def vectntr(A,B,ph1,om,n,num,N):
    z=spectrum_om(A,B,ph1,om); q=z['Wv']; Gam=z['Gam']; Vv=np.zeros(7,dtype=complex)
    if n<0:
        yz1=reg_spectrq(q[3],A,B,ph1,n); yzr1=reg_spectrq(-q[0],A,B,ph1,n); yzr2=reg_spectrq(q[2],A,B,ph1,n)
        yzrev=reg_spectrq(-1j*Gam if np.real(Gam)>0 else 1j*Gam,A,B,ph1,n)
        Vv[:4]=[yz1['V'][num-1],yzr1['V'][num-1],yzr2['V'][num-1],yzrev['V'][num-1]]
    else:
        yzt1=reg_spectrq(q[0],A,B,ph1,n); yzt2=reg_spectrq(q[3],A,B,ph1,n)
        yztev=reg_spectrq(1j*Gam if np.real(Gam)>0 else -1j*Gam,A,B,ph1,n)
        Vv[4:]=[np.exp(1j*q[0]*(N-1))*yzt1['V'][num-1],np.exp(1j*q[3]*(N-1))*yzt2['V'][num-1],yztev['V'][num-1]]
    return Vv
