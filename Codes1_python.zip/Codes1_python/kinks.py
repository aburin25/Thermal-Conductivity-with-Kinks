import numpy as np

def generate_next(Coord,phics,ph,ph1,Ymax,l,Set,rng=None):
    rng=np.random.default_rng() if rng is None else rng; Coord=np.asarray(Coord,float); N=Coord.shape[1]
    if phics[-1]!=0:
        phics=np.r_[phics,0]; ll=2+2*rng.poisson((l-2)/2); XX=np.arange(1,ll+1); YY=np.tan(ph)*((-1.0)**(XX+N)-(-1.0)**N)/2; X=XX+Coord[0,-1]; Y=YY+Coord[1,-1]
    else:
        Tst=True; phic=(-1)**N*ph1; phics=np.r_[phics,phic]
        while Tst:
            ll=1+rng.poisson((l-1)/2); XX0=np.arange(1,ll+1); YY0=np.tan(ph)*((-1.0)**(XX0+N)-(-1.0)**N)/2; XX=XX0*np.cos(phic)-YY0*np.sin(phic); YY=XX0*np.sin(phic)+YY0*np.cos(phic); X=XX+Coord[0,-1]; Y=YY+Coord[1,-1]; Tst=np.max(np.abs(Y-.5))>=Ymax
    return {'Coord':np.column_stack((Coord,np.vstack((X,Y)))),'Set':np.r_[Set,ll],'phics':phics}

def generate_real_kinks_restr(ph,ph1,Ymax,l,k,rng=None):
    rng=np.random.default_rng() if rng is None else rng; ll=1+rng.poisson(l-1); Set=np.array([ll]); phics=np.array([0.]); XX=np.arange(ll); YY=np.tan(ph)*(1+(-1.0)**np.arange(1,ll+1))/2; Coord=np.vstack((XX,YY))
    for _ in range(k):
        z=generate_next(Coord,phics,ph,ph1,Ymax,l,Set,rng); Coord,phics,Set=z['Coord'],z['phics'],z['Set']
    return z

def generate_real_kinks_pos(Set,ph,ph1):
    Set=np.asarray(Set,int).reshape(-1); Sums=np.r_[0,np.cumsum(Set)]; n=len(Set); X=np.zeros(Sums[-1]); Y=np.zeros(Sums[-1]); X0=Y0=0.; phc=0.
    for ii in range(n):
        In=Sums[ii]; Fin=Sums[ii+1]-1; XX0=np.arange(Fin-In+1); inds=np.arange(In,Fin+1); YY0=((-1.0)**(inds+1)-(-1.0)**(In+1))*np.tan(ph)/2; XX=XX0*np.cos(phc)-YY0*np.sin(phc); YY=XX0*np.sin(phc)+YY0*np.cos(phc); X[inds]=X0+XX; Y[inds]=Y0+YY
        if phc!=0: phc=0
        else: phc=ph1*(-1)**(Fin+1)
        dX=1.; dY=-np.tan(ph)*(-1)**(Fin+1); X0=X[Fin]+dX*np.cos(phc)-dY*np.sin(phc); Y0=Y[Fin]+dX*np.sin(phc)+dY*np.cos(phc)
    return {'Coord':np.vstack((X,Y))}

def generate_real_kinks_rw(k,l,ph1,rng=None):
    rng=np.random.default_rng() if rng is None else rng
    while True:
        Set=1+rng.poisson(l-1,size=k)
        if Set.sum()<k*l:
            Sums=np.cumsum(Set); Signs=(-1.)**Sums; Phis=np.r_[0,np.cumsum(Signs)*ph1]
            if np.isclose(Phis[-1],0): break
    Set=np.r_[Set,k*l-Set.sum()+1]; SetExt=Set.copy(); SetExt[0]+=2; SetExt[-1]+=2
    return {'Set':Set,'Phis':Phis,'SetExt':SetExt}

def generate_real_kinks_pos_rw(Set,Phis,ph):
    Sums=np.r_[0,np.cumsum(Set)]; n=len(Set); X=np.zeros(Sums[-1]); Y=np.zeros(Sums[-1]); X0=Y0=0.; Phis1=np.r_[Phis,0]
    for ii in range(n):
        phc=Phis1[ii]; In=Sums[ii]; Fin=Sums[ii+1]-1; inds=np.arange(In,Fin+1); XX0=np.arange(Fin-In+1); YY0=((-1.0)**(inds+1)-(-1.0)**(In+1))*np.tan(ph)/2; XX=XX0*np.cos(phc)-YY0*np.sin(phc); YY=XX0*np.sin(phc)+YY0*np.cos(phc); X[inds]=X0+XX; Y[inds]=Y0+YY; dX=1.; dY=-np.tan(ph)*(-1)**(Fin+1); X0=X[Fin]+dX*np.cos(Phis1[ii+1])-dY*np.sin(Phis1[ii+1]); Y0=Y[Fin]+dX*np.sin(Phis1[ii+1])+dY*np.cos(Phis1[ii+1])
    return {'Coord':np.vstack((X,Y))}

def generate_real_kinks_rw_coord(k,l,ph,ph1,rng=None):
    rng=np.random.default_rng() if rng is None else rng
    while True:
        z=generate_real_kinks_rw(k,l,ph1,rng); yz=generate_real_kinks_pos_rw(z['SetExt'],z['Phis'],ph)
        if abs(yz['Coord'][1,-1])<1e-10:return {'CoordExt':yz['Coord']}

def generate_restr_kinks_coord(ph,ph1,Ymax,l,k,rng=None):
    rng=np.random.default_rng() if rng is None else rng
    while True:
        yz=generate_real_kinks_restr(ph,ph1,Ymax,l,k,rng); Summ=yz['Set'][:-1].sum(); N=yz['Coord'].shape[1]
        if Summ<l*k:
            nn=1+(1-(-1)**Summ)/2
            if abs(yz['Coord'][1,Summ]-yz['Coord'][1,int(nn)-1])<1e-10: break
    Set=yz['Set'].copy(); Set[0]+=2; Set[-1]+=3 if N%2==0 else 2; Str=generate_real_kinks_pos(Set,ph,ph1); yz['yz']=yz; yz['SetExt']=Set; yz['CoordExt']=Str['Coord']; return yz
