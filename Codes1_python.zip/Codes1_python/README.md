# Codes1 — MATLAB to Python conversion

This package is a Python/Numpy/SciPy translation of the MATLAB files supplied in `Codes1.zip`. The original README describes `ThermCondKinksRealDefRestr` as evaluating thermal conductivity by integrated transmission for strongly aligned chains, and `ThermCondKinksRealRWDef` for random-walk chains. fileciteturn0file0L3-L7

## Requirements

Python 3.10+ with `numpy` and `scipy`.

```bash
pip install numpy scipy
```

## Main functions

```python
from Codes1_python.thermcond import therm_cond_kinks_real_def_restr, therm_cond_kinks_real_rw_def
```

The translated functions preserve the MATLAB parameter order:

```python
therm_cond_kinks_real_def_restr(l, k, A, B, ph, ph1, n1, n2, xi, Ym)
therm_cond_kinks_real_rw_def(l, k, A, B, ph, ph1, n1, n2, xi)
```

The returned dictionary contains `k`, `Dk`, and `samples` (the last item is an additional Python convenience). The source README defines `l`, `k`, `A`, `B`, `ph`, `ph1`, `n1`, `n2`, `xi`, and `Ym` as the model parameters and reports averaged transmission and relative error as the outcome. fileciteturn0file0L8-L19

## Notes

- MATLAB's `poissrnd` is implemented with NumPy's Poisson generator.
- MATLAB's `integral` is implemented with `scipy.integrate.quad`.
- MATLAB linear solves (`\\`) use `numpy.linalg.solve`.
- Complex quantities are represented with NumPy complex arrays.
- MATLAB `parfor` in `TransmVect` is implemented as a normal Python loop for portability and reproducibility.
- The conversion preserves the source algorithms rather than redesigning them.

## Important validation note

This is a source-level translation. Numerical equivalence should be checked against MATLAB for representative parameter sets, especially near singular frequencies and in the random-generation routines.
