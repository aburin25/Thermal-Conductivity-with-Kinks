import numpy as np
from scipy.optimize import brentq

def reg_spectrq(q,A,B,ph1,n=0):
    q=np.asarray(q,dtype=complex) if np.iscomplexobj(q) else q
    om2=A*(1-np.cos(q)*np.cos(2*ph1))+B*(1-np.cos(2*q))-np.sqrt((A*(np.cos(2*ph1)-np.cos(q))+B*(1-np.cos(2*q)))**2+A**2*(np.sin(q)*np.sin(2*ph1))**2)
    om2d1=A*np.sin(q)*np.cos(2*ph1)+2*B*np.sin(2*q)
    om2d2a=2*(A*(np.cos(2*ph1)-np.cos(q))+B*(1-np.cos(2*q)))*(A*np.sin(q)+2*B*np.sin(2*q))+2*A**2*np.sin(2*ph1)**2*np.sin(q)*np.cos(q)
    om2d3a=.5*om2d2a/np.sqrt((A*(np.cos(2*ph1)-np.cos(q))+B*(1-np.cos(2*q)))**2+A**2*(np.sin(q)*np.sin(2*ph1))**2)
    OmDer2=.5*(om2d1-om2d3a)/np.sqrt(om2)
    om=np.sqrt(om2)
    Bl1=-om**2+2*A*(1-np.cos(q))*np.cos(ph1)**2+2*B*(1-np.cos(2*q))
    Bl2=1j*np.sin(q)*np.sin(2*ph1)*A
    v=np.array([1,-Bl1/Bl2],dtype=complex)/np.sqrt(1+abs(Bl1)**2/abs(Bl2)**2)
    vm2=np.array([np.exp(-2j*q)*v[0],np.exp(-2j*q)*v[1]])
    vm1=np.array([np.exp(-1j*q)*v[0],-np.exp(-1j*q)*v[1]])
    v1=np.array([np.exp(1j*q)*v[0],-np.exp(1j*q)*v[1]])
    v2=np.array([np.exp(2j*q)*v[0],np.exp(2j*q)*v[1]])
    Check1=-om**2*v[0]+A*np.cos(ph1)**2*(2*v[0]-v1[0]-vm1[0])+B*(2*v[0]-v2[0]-vm2[0])-A*np.sin(2*ph1)*(v1[1]-vm1[1])/2
    Check2=-om**2*v[1]+A*np.sin(ph1)**2*(2*v[1]-v1[1]-vm1[1])-A*np.sin(2*ph1)*(v1[0]-vm1[0])/2
    vn=np.array([np.exp(1j*q*n)*v[0],(-1)**n*np.exp(1j*q*n)*v[1]])
    return {'om':om,'ch1':Check1,'ch2':Check2,'V':vn,'vg':OmDer2}

def spectrum_om(A,B,ph1,om):
    Pol=[-8*A*B*np.sin(ph1)**2,-8*A*B*np.sin(ph1)**2+4*om**2*B,8*A*B*np.sin(ph1)**2+2*A*om**2*np.cos(2*ph1),8*A*B*np.sin(ph1)**2-4*om**2*B-2*A*om**2+om**4]
    Roots=np.roots(Pol); Roots=Roots[np.argsort(np.abs(Roots))]
    q1=np.arccos(Roots[1]); q2=np.arccos(Roots[0]); q=np.array([q1,-q1,q2,-q2])
    if np.real(Roots[2])>0: Gam=np.log(Roots[2]+np.sqrt(Roots[2]**2-1))
    else: Gam=np.log(abs(Roots[2])+np.sqrt(Roots[2]**2-1))+1j*np.pi
    Bl1=-om**2+2*A*(1-np.cos(q))*np.cos(ph1)**2+2*B*(1-np.cos(2*q)); Bl2=1j*np.sin(q)*np.sin(2*ph1)*A
    Rats=np.column_stack((np.ones(4),Bl2/Bl1)); Norm=np.sqrt(np.abs(Rats[:,0])**2+np.abs(Rats[:,1])**2)
    return {'Vsq':Rats/Norm[:,None],'Wv':q,'Gam':Gam,'ImExp':np.array([Roots[1]+1j*np.sqrt(1-Roots[1]**2),Roots[1]-1j*np.sqrt(1-Roots[1]**2),Roots[0]+1j*np.sqrt(1-Roots[0]**2),Roots[0]-1j*np.sqrt(1-Roots[0]**2)]),'ReExp':np.array([Roots[2]+np.sqrt(Roots[2]**2-1),Roots[2]-np.sqrt(Roots[2]**2-1)])}

def vgroup(q,A,B,ph1): return reg_spectrq(q,A,B,ph1,0)['vg']

def om_max(A,B,ph1):
    z=brentq(lambda x: np.real(vgroup(x,A,B,ph1)),1e-8,np.pi-1e-8)
    return np.real(reg_spectrq(z,A,B,ph1,0)['om'])
