"""
core.py  –  spectrum, dispersion, and Green function utilities
Translated from MATLAB by Claude (2026).
"""

import numpy as np
from dataclasses import dataclass, field
from typing import NamedTuple


# ---------------------------------------------------------------------------
# SpectrumOm
# ---------------------------------------------------------------------------

class SpectrumResult(NamedTuple):
    Vsq: np.ndarray   # (4,2) normalised eigenvectors
    Wv: np.ndarray    # [q1, -q1, q2, -q2]
    Gam: complex
    ImExp: np.ndarray
    ReExp: np.ndarray


def spectrum_om(A: float, B: float, ph1: float, om: float) -> SpectrumResult:
    """
    Return wavevectors and evanescent decay constant for frequency *om*.
    Corresponds to MATLAB SpectrumOm.
    """
    # Characteristic polynomial coefficients (in cos(q))
    Pol = np.array([
        -8 * A * B * np.sin(ph1)**2,
        -8 * A * B * np.sin(ph1)**2 + 4 * om**2 * B,
         8 * A * B * np.sin(ph1)**2 + 2 * A * om**2 * np.cos(2 * ph1),
         8 * A * B * np.sin(ph1)**2 - 4 * om**2 * B - 2 * A * om**2 + om**4,
    ])
    Roots = np.roots(Pol)
    ord_ = np.argsort(np.abs(Roots))
    Roots = Roots[ord_]

    q1 = np.arccos(Roots[1])
    q2 = np.arccos(Roots[0])
    q = np.array([q1, -q1, q2, -q2])

    r3 = Roots[2]
    if r3.real > 0:
        Gam = np.log(r3 + np.sqrt(r3**2 - 1))
    else:
        Gam = np.log(np.abs(r3) + np.sqrt(r3**2 - 1)) + 1j * np.pi

    Bl1 = -om**2 + 2*A*(1 - np.cos(q))*np.cos(ph1)**2 + 2*B*(1 - np.cos(2*q))
    Bl2 = 1j * np.sin(q) * np.sin(2*ph1) * A
    Rats = np.column_stack([np.ones(4), (Bl2 / Bl1)])
    Norm = np.sqrt(np.abs(Rats[:, 0])**2 + np.abs(Rats[:, 1])**2)
    Vsq = Rats / Norm[:, None]

    ImExp = np.array([
        Roots[1] + 1j*np.sqrt(1 - Roots[1]**2),
        Roots[1] - 1j*np.sqrt(1 - Roots[1]**2),
        Roots[0] + 1j*np.sqrt(1 - Roots[0]**2),
        Roots[0] - 1j*np.sqrt(1 - Roots[0]**2),
    ])
    ReExp = np.array([
        Roots[2] + np.sqrt(Roots[2]**2 - 1),
        Roots[2] - np.sqrt(Roots[2]**2 - 1),
    ])

    return SpectrumResult(Vsq=Vsq, Wv=q, Gam=Gam, ImExp=ImExp, ReExp=ReExp)


# ---------------------------------------------------------------------------
# RegSpectrq
# ---------------------------------------------------------------------------

class RegSpectrResult(NamedTuple):
    om: complex
    ch1: complex
    ch2: complex
    V: np.ndarray   # [v(0), v(1)] at site n
    vg: complex     # group velocity  dω/dq


def reg_spectr_q(q: complex, A: float, B: float, ph1: float, n: int) -> RegSpectrResult:
    """
    Eigenvector and group velocity at wavevector *q*.
    Corresponds to MATLAB RegSpectrq.
    """
    om2 = (A*(1 - np.cos(q)*np.cos(2*ph1)) + B*(1 - np.cos(2*q))
           - np.sqrt((A*(np.cos(2*ph1) - np.cos(q)) + B*(1 - np.cos(2*q)))**2
                     + A**2*(np.sin(q)*np.sin(2*ph1))**2))

    om2Der1 = A * np.sin(q) * np.cos(2*ph1) + 2*B * np.sin(2*q)
    inner = (A*(np.cos(2*ph1) - np.cos(q)) + B*(1 - np.cos(2*q)))
    om2Der2a = (2 * inner * (A*np.sin(q) + 2*B*np.sin(2*q))
                + 2 * A**2 * np.sin(2*ph1)**2 * np.sin(q) * np.cos(q))
    om2Der3a = 0.5 * om2Der2a / np.sqrt(inner**2 + A**2*(np.sin(q)*np.sin(2*ph1))**2)
    OmDer2 = 0.5 * (om2Der1 - om2Der3a) / np.sqrt(om2)

    om = np.sqrt(om2)

    Bl1 = -om2 + 2*A*(1 - np.cos(q))*np.cos(ph1)**2 + 2*B*(1 - np.cos(2*q))
    Bl2 = 1j * np.sin(q) * np.sin(2*ph1) * A
    v_raw = np.array([1, -Bl1/Bl2])
    v = v_raw / np.sqrt(1 + np.abs(Bl1)**2 / np.abs(Bl2)**2)

    vm2 = np.array([np.exp(-1j*2*q)*v[0],  np.exp(-2j*q)*v[1]])
    vm1 = np.array([np.exp(-1j*q)*v[0],   -np.exp(-1j*q)*v[1]])
    v1  = np.array([np.exp( 1j*q)*v[0],   -np.exp( 1j*q)*v[1]])
    v2  = np.array([np.exp( 2j*q)*v[0],    np.exp( 2j*q)*v[1]])

    Check1 = (-om**2*v[0] + A*np.cos(ph1)**2*(2*v[0] - v1[0] - vm1[0])
              + B*(2*v[0] - v2[0] - vm2[0]) - A*np.sin(2*ph1)*(v1[1] - vm1[1])/2)
    Check2 = (-om**2*v[1] + A*np.sin(ph1)**2*(2*v[1] - v1[1] - vm1[1])
              - A*np.sin(2*ph1)*(v1[0] - vm1[0])/2)

    vn = np.array([np.exp(1j*q*n)*v[0],
                   (-1)**n * np.exp(1j*q*n)*v[1]])

    return RegSpectrResult(om=om, ch1=Check1, ch2=Check2, V=vn, vg=OmDer2)


# ---------------------------------------------------------------------------
# G0Vect  and  G0Matr
# ---------------------------------------------------------------------------

def g0_vect(m: np.ndarray, n: np.ndarray,
            alph: int, bet: int,
            A: float, B: float, ph: float, om: float):
    """
    Bulk Green function vector.  alph, bet ∈ {1, 2}.
    Returns (G_total, dict with G01, G02, G03).
    Corresponds to MATLAB G0Vect.
    """
    m = np.atleast_1d(m).reshape(-1, 1).astype(complex)
    n = np.atleast_1d(n).reshape(1, -1).astype(complex)

    Sp = spectrum_om(A, B, ph, om)
    q1, q2 = Sp.Wv[0], Sp.Wv[3]
    Gamm = np.sign(Sp.Gam.real) * Sp.Gam

    RS = reg_spectr_q(q1, A, B, ph, 0)
    V1pl = np.conj(RS.V)
    v1   = RS.vg
    V1min = RS.V

    RS = reg_spectr_q(q2, A, B, ph, 0)
    V2pl = np.conj(RS.V)
    v2   = RS.vg
    V2min = RS.V

    RS  = reg_spectr_q( 1j*Gamm, A, B, ph, 0)
    RS1 = reg_spectr_q(-1j*Gamm, A, B, ph, 0)
    Vgampl  = np.conj(RS.V)
    vgam    = RS.vg
    Vgammin = np.conj(RS1.V)

    diff = m - n   # broadcast (len_m, len_n)
    sgn  = np.sign(diff)

    # indices are 0-based inside arrays, alph/bet are 1-based
    a, b = alph - 1, bet - 1

    G01 = (np.exp(1j*q1*np.abs(diff))
           * (V1pl[a]*V1min[b]*(1 + sgn)/2 + V1pl[b]*V1min[a]*(1 - sgn)/2)
           / (1j * 2 * v1 * om))

    G02 = (np.exp(1j*q2*np.abs(diff))
           * (V2pl[a]*V2min[b]*(1 + sgn)/2 + V2pl[b]*V2min[a]*(1 - sgn)/2)
           / (1j * 2 * v2 * om))

    denom03 = 2j * vgam * om * (Vgammin[0]**2 - Vgammin[1]**2)
    G03 = (np.exp(-Gamm*np.abs(diff))
           * (Vgampl[a]*Vgammin[b]*(1 + sgn)/2 + Vgampl[b]*Vgammin[a]*(1 - sgn)/2)
           / denom03)

    phase = (-1)**((alph - 1)*(m - 1) + (bet - 1)*n + bet)
    G01_ = G01 * phase
    G02_ = G02 * phase
    G03_ = G03 * phase

    G = G01_ + G02_ + G03_
    return G, {"G01": G01_, "G02": G02_, "G03": G03_}


def g0_matr(m: np.ndarray, n: np.ndarray, N: int, Typ: int,
            A: float, B: float, ph: float, om: float) -> np.ndarray:
    """
    Assemble 2×2 block Green function matrix.
    Corresponds to MATLAB G0Matr.
    """
    m = np.atleast_1d(m)
    n = np.atleast_1d(n)

    ms1 = m[m < N + 1];  ms2 = m[m > N] - N
    ns1 = n[n < N + 1];  ns2 = n[n > N] - N

    def _block(mm, nn, a, b, key):
        _, d = g0_vect(mm, nn, a, b, A, B, ph, om)
        if Typ == 1:   return d["G01"]
        elif Typ == 2: return d["G02"]
        elif Typ == 3: return d["G03"]
        else:
            G, _ = g0_vect(mm, nn, a, b, A, B, ph, om)
            return G

    G11 = _block(ms1, ns1, 1, 1, Typ)
    G12 = _block(ms1, ns2, 1, 2, Typ)
    G21 = _block(ms2, ns1, 2, 1, Typ)
    G22 = _block(ms2, ns2, 2, 2, Typ)

    return np.block([[G11, G12], [G21, G22]])


# ---------------------------------------------------------------------------
# Gs  –  local Green function by direct solve
# ---------------------------------------------------------------------------

def gs(n1: np.ndarray, n2: np.ndarray,
       H: np.ndarray, om: float) -> np.ndarray:
    """
    Green function G(n1, n2) = [(ω²I - H)^{-1}]_{n1, n2}.
    Corresponds to MATLAB Gs.
    """
    n1 = np.atleast_1d(n1) - 1   # convert to 0-based
    n2 = np.atleast_1d(n2) - 1
    N  = H.shape[0]
    A  = om**2 * np.eye(N) - H
    result = np.zeros((len(n1), len(n2)), dtype=complex)
    for j, idx in enumerate(n2):
        rhs = np.zeros(N)
        rhs[idx] = 1.0
        sol = np.linalg.solve(A, rhs)
        result[:, j] = sol[n1]
    return result
