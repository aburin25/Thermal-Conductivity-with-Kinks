"""
thermal.py  –  Hessian with kink defect, block extraction, transmission
               integrand, and thermal conductivity calculation.
Translated from MATLAB by Claude (2026).
"""

import numpy as np
from scipy import integrate
from .geometry import hess_matr_add_2d
from .core import spectrum_om, reg_spectr_q
from .transport import self_energ, get_trsl, get_trst
from .generate import generate_restr_kinks_coord, generate_real_kinks_rw_coord


# ---------------------------------------------------------------------------
# Hessian2DOpDef  –  Hessian with modified NNN spring at kink sites
# ---------------------------------------------------------------------------

def hessian_2d_op_def(Coord: np.ndarray,
                       A: float, B: float, xi: float) -> dict:
    """
    Build 2N×2N Hessian. NNN spring constant is xi*B when the NNN distance
    differs from 2 (i.e. at kink sites), otherwise B.
    Corresponds to MATLAB Hessian2DOpDef.
    """
    if Coord.shape[0] == 2:
        Coord = Coord.T
    N = Coord.shape[0]
    H = np.zeros((2 * N, 2 * N))

    for ii in range(N - 1):
        r1 = Coord[ii]
        r2 = Coord[ii + 1]
        idx = [ii, N + ii, ii + 1, N + ii + 1]
        H[np.ix_(idx, idx)] += hess_matr_add_2d(r1, r2, A)

        if ii < N - 2:
            r3 = Coord[ii + 2]
            B_eff = xi * B if abs(np.linalg.norm(r1 - r3) - 2.0) > 1e-10 else B
            idx2 = [ii, N + ii, ii + 2, N + ii + 2]
            H[np.ix_(idx2, idx2)] += hess_matr_add_2d(r1, r3, B_eff)

    return {"H0": H}


# ---------------------------------------------------------------------------
# BlocksCoordDef  –  build Hessian and extract lead-coupling blocks
# ---------------------------------------------------------------------------

def blocks_coord_def(CoordIn: np.ndarray,
                     A: float, B: float,
                     ph: float, xi: float) -> dict:
    """
    Given interior coordinates CoordIn (2, N_inner) or (N_inner, 2),
    prepend and append two lead sites, build the full Hessian, and
    extract the scattering-region and lead-coupling blocks.
    Corresponds to MATLAB BlocksCoordDef.
    """
    if CoordIn.shape[0] == 2:
        CoordIn = CoordIn.T          # → (N_inner, 2)

    xm2, ym2 = -2.0, 0.0
    xm1, ym1 = -1.0, np.tan(ph)
    x2,  y2  = CoordIn[-1, 0] + 2.0, CoordIn[-1, 1]
    x1,  y1  = CoordIn[-1, 0] + 1.0, CoordIn[-1, 1] + np.tan(ph)

    Coord = np.row_stack([
        [xm2, ym2], [xm1, ym1],
        CoordIn,
        [x1, y1], [x2, y2],
    ])
    N = CoordIn.shape[0] - 1

    yz = hessian_2d_op_def(Coord, A, B, xi)
    H  = yz["H0"]

    # 0-based index sets (MATLAB 1-based → subtract 1)
    Sites      = list(range(2, 3 + N)) + list(range(N + 7, 2 * N + 8))
    Sitesl     = [0, 1, N + 6]
    Sitesr     = [N + 3, N + 4, 2 * N + 8]
    SitesInl   = [2, 3, N + 7, N + 8]
    SitesInr   = [N + 1, N + 2, 2 * N + 6, 2 * N + 7]
    SitesInTot = list(range(2, N + 3)) + list(range(N + 7, 2 * N + 8))

    return {
        "Hin":  H[np.ix_(Sites, Sites)],
        "Vl":   H[np.ix_(Sitesl,  SitesInl)],
        "Vlt":  H[np.ix_(Sitesl,  SitesInTot)],
        "Vr":   H[np.ix_(Sitesr,  SitesInr)],
        "Vrt":  H[np.ix_(Sitesr,  SitesInTot)],
        "Ht":   H,
        "Coord": Coord,
    }


# ---------------------------------------------------------------------------
# OmMax  –  maximum phonon frequency (band edge)
# ---------------------------------------------------------------------------

def om_max(A: float, B: float, ph: float) -> float:
    """
    Find the maximum phonon frequency by locating the zero of the group
    velocity and evaluating the dispersion there.
    Corresponds to MATLAB OmMax / vgroup.
    """
    from scipy.optimize import brentq

    def vgroup(q):
        rs = reg_spectr_q(q, A, B, ph, 0)
        return rs.vg.real

    # scan for a sign change
    q_vals = np.linspace(0.01, np.pi - 0.01, 500)
    vg     = np.array([vgroup(q) for q in q_vals])
    sign_changes = np.where(np.diff(np.sign(vg)))[0]

    if len(sign_changes) == 0:
        # fallback: maximum of dispersion by sampling
        oms = np.array([reg_spectr_q(q, A, B, ph, 0).om.real for q in q_vals])
        return float(np.max(oms))

    q_zero = brentq(vgroup, q_vals[sign_changes[0]], q_vals[sign_changes[0] + 1])
    rs = reg_spectr_q(q_zero, A, B, ph, 0)
    return float(rs.om.real)


# ---------------------------------------------------------------------------
# Transmission  –  total T(ω) for the thermal conductivity integrand
# ---------------------------------------------------------------------------

def transmission_scalar(om: float,
                         Vl: np.ndarray, Vr: np.ndarray, H: np.ndarray,
                         A: float, B: float, ph: float) -> float:
    """
    Return total transmission coefficient T = T_l + T_t at frequency *om*.
    Returns 0 if the frequency is outside the propagating band or the
    linear system is singular.
    Corresponds to MATLAB Transmission (Codes1 version).
    """
    # check propagating band
    Sp = spectrum_om(A, B, ph, om)
    if abs(Sp.Wv[0].imag) > 1e-4:
        return 0.0
    try:
        Sigm = self_energ(om, Vl, Vr, H)
        N    = H.shape[0]
        Trl, y1 = get_trsl(N, A, B, ph, om, Sigm)
        Trt, y2 = get_trst(N, A, B, ph, om, Sigm)
        T = float(np.real(Trl + Trt))
        if T > 2.0:
            print(f"Warning: T={T:.4f} > 2 at om={om:.4f}")
        if abs(y1["Check"]) > 0.1 or abs(y2["Check"]) > 0.1:
            print(f"Warning: normalisation fails at om={om:.4f}")
        return max(0.0, T)
    except np.linalg.LinAlgError:
        return 0.0


def transm_vect(H: np.ndarray, Vl: np.ndarray, Vr: np.ndarray,
                A: float, B: float, ph: float,
                Om: np.ndarray) -> np.ndarray:
    """
    Evaluate transmission at an array of frequencies (vectorised).
    Corresponds to MATLAB TransmVect.
    """
    return np.array([transmission_scalar(om, Vl, Vr, H, A, B, ph)
                     for om in np.atleast_1d(Om)])


# ---------------------------------------------------------------------------
# Thermal conductivity  –  restricted (strongly-aligned) chains
# ---------------------------------------------------------------------------

def therm_cond_restr(l: float, k: int,
                     A: float, B: float, ph: float, ph1: float,
                     n1: int, n2: int,
                     xi: float, Ym: float,
                     save_file: bool = True) -> dict:
    """
    Compute thermal conductance κ (proportional to integrated transmission)
    for strongly-aligned kink chains with bounded vertical displacement.

    Parameters
    ----------
    l   : mean spacing between kinks
    k   : number of kinks (must be divisible by 4)
    A   : nearest-neighbour spring constant
    B   : next-nearest-neighbour spring constant
    ph  : chain tilt angle (radians)
    ph1 : kink angle (radians)
    n1, n2 : index range of random realisations to compute
    xi  : ratio of NNN spring constant at kink sites to bulk value
    Ym  : maximum allowed vertical displacement
    save_file : if True, append each realisation result to a text file

    Returns
    -------
    dict with keys:
        'kappa'  – mean normalised conductance
        'Dk'     – relative statistical error
        'values' – array of per-realisation values
    Corresponds to MATLAB ThermCondKinksRealDefRestr.
    """
    fname = (f"ThCondRealDefRestrl{l}k{k}A{A}B{B}"
             f"ph{ph:.4f}ph1{ph1:.4f}xi{xi}Ym{Ym}.txt")

    Om_max = om_max(A, B, ph)
    values = []

    for ii in range(n1, n2 + 1):
        yzz = generate_restr_kinks_coord(ph, ph1, Ym, l, k)
        yz  = blocks_coord_def(yzz["CoordExt"], A, B, ph, xi)

        def integrand(Om_arr):
            return transm_vect(yz["Hin"], yz["Vl"], yz["Vr"], A, B, ph, Om_arr)

        II, _ = integrate.quad(
            lambda x: float(transm_vect(yz["Hin"], yz["Vl"], yz["Vr"],
                                         A, B, ph, np.array([x]))[0]),
            1e-6, Om_max,
            limit=200, epsrel=2.5e-3, epsabs=1e-3 / (k * l)
        )
        val = II * k * l
        values.append(val)
        if save_file:
            with open(fname, "a") as f:
                f.write(f"{val:.14e}\n")
        print(f"  Realisation {ii}: κ·kl = {val:.6f}")

    values = np.array(values)
    kappa  = float(np.mean(values))
    Dk     = float(np.std(values) / (kappa * np.sqrt(len(values)))) if kappa != 0 else np.nan

    return {"kappa": kappa, "Dk": Dk, "values": values}


# ---------------------------------------------------------------------------
# Thermal conductivity  –  random-walk chains
# ---------------------------------------------------------------------------

def therm_cond_rw(l: float, k: int,
                  A: float, B: float, ph: float, ph1: float,
                  n1: int, n2: int,
                  xi: float,
                  save_file: bool = True) -> dict:
    """
    Compute thermal conductance for random-walk kink chains.

    Parameters
    ----------
    (same as therm_cond_restr except no Ym argument)

    Returns
    -------
    dict with keys 'kappa', 'Dk', 'values'
    Corresponds to MATLAB ThermCondKinksRealRWDef.
    """
    fname = (f"ThCondRealRWDefl{l}k{k}A{A}B{B}"
             f"ph{ph:.4f}ph1{ph1:.4f}xi{xi}.txt")

    Om_max = om_max(A, B, ph)
    values = []

    for ii in range(n1, n2 + 1):
        CoordExt = generate_real_kinks_rw_coord(k, l, ph, ph1)
        yz       = blocks_coord_def(CoordExt, A, B, ph, xi)

        II, _ = integrate.quad(
            lambda x: float(transm_vect(yz["Hin"], yz["Vl"], yz["Vr"],
                                         A, B, ph, np.array([x]))[0]),
            1e-6, Om_max,
            limit=200, epsrel=2.5e-3, epsabs=1e-6
        )
        val = II * k * l
        values.append(val)
        if save_file:
            with open(fname, "a") as f:
                f.write(f"{val:.14e}\n")
        print(f"  Realisation {ii}: κ·kl = {val:.6f}")

    values = np.array(values)
    kappa  = float(np.mean(values))
    Dk     = float(np.std(values) / (kappa * np.sqrt(len(values)))) if kappa != 0 else np.nan

    return {"kappa": kappa, "Dk": Dk, "values": values}
