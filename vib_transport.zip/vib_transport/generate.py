"""
generate.py  –  random kink chain coordinate generators
Translated from MATLAB by Claude (2026).
"""

import numpy as np


# ---------------------------------------------------------------------------
# Low-level helpers
# ---------------------------------------------------------------------------

def generate_real_kinks_pos(Set: np.ndarray, ph: float, ph1: float) -> np.ndarray:
    """
    Build (2, N_total) coordinate array from a segment-length array *Set*
    for a strongly-aligned (restricted) kink chain.
    Corresponds to MATLAB GenerateRealKinksPos.
    Returns Coord as (2, N) array.
    """
    Set = np.atleast_1d(Set).flatten().astype(int)
    Sums = np.concatenate([[0], np.cumsum(Set)])
    n    = len(Set)
    N_total = int(Sums[-1])
    X = np.zeros(N_total)
    Y = np.zeros(N_total)
    X0, Y0, phc = 0.0, 0.0, 0.0

    for ii in range(n):
        In  = int(Sums[ii])
        Fin = int(Sums[ii + 1])
        XX0 = np.arange(0, Fin - In)
        # MATLAB uses 1-based indices: In_m = In+1, Fin_m = Fin
        idx_m = np.arange(In + 1, Fin + 1)        # 1-based parity (MATLAB In:Fin)
        In_m  = In + 1                             # 1-based start index
        YY0 = ((-1.0)**idx_m - (-1.0)**In_m) * np.tan(ph) / 2
        XX  = XX0 * np.cos(phc) - YY0 * np.sin(phc)
        YY  = XX0 * np.sin(phc) + YY0 * np.cos(phc)
        X[In:Fin] = X0 + XX
        Y[In:Fin] = Y0 + YY
        # update origin and angle for next segment
        if phc != 0:
            phc = 0.0
        else:
            phc = ph1 * (-1.0)**Fin  # Fin is MATLAB Fin (1-based end of segment)
        dX = 1.0
        dY = -np.tan(ph) * (-1.0)**Fin
        X0 = X[Fin - 1] + dX * np.cos(phc) - dY * np.sin(phc)
        Y0 = Y[Fin - 1] + dX * np.sin(phc) + dY * np.cos(phc)

    return np.row_stack([X, Y])


def generate_real_kinks_pos_rw(Set: np.ndarray,
                                Phis: np.ndarray,
                                ph: float) -> np.ndarray:
    """
    Build coordinates for a random-walk kink chain.
    Corresponds to MATLAB GenerateRealKinksPosRW.
    Returns Coord as (2, N) array.
    """
    Set  = np.atleast_1d(Set).flatten().astype(int)
    Phis = np.atleast_1d(Phis).flatten()
    Sums = np.concatenate([[0], np.cumsum(Set)])
    n    = len(Set)
    N_total = int(Sums[-1])
    X = np.zeros(N_total)
    Y = np.zeros(N_total)
    X0, Y0 = 0.0, 0.0
    Phis1 = np.append(Phis, 0.0)

    for ii in range(n):
        phc = Phis1[ii]
        In  = int(Sums[ii])
        Fin = int(Sums[ii + 1])
        XX0   = np.arange(0, Fin - In)
        idx_m = np.arange(In + 1, Fin + 1)   # 1-based parity (MATLAB In:Fin)
        In_m  = In + 1                         # 1-based start index
        YY0 = ((-1.0)**idx_m - (-1.0)**In_m) * np.tan(ph) / 2
        XX  = XX0 * np.cos(phc) - YY0 * np.sin(phc)
        YY  = XX0 * np.sin(phc) + YY0 * np.cos(phc)
        X[In:Fin] = X0 + XX
        Y[In:Fin] = Y0 + YY
        dX = 1.0
        dY = -np.tan(ph) * (-1.0)**Fin
        X0 = X[Fin - 1] + dX * np.cos(Phis1[ii + 1]) - dY * np.sin(Phis1[ii + 1])
        Y0 = Y[Fin - 1] + dX * np.sin(Phis1[ii + 1]) + dY * np.cos(Phis1[ii + 1])

    return np.row_stack([X, Y])


# ---------------------------------------------------------------------------
# Restricted (strongly-aligned) chain generation
# ---------------------------------------------------------------------------

def generate_next(Coord: np.ndarray, phics: list,
                  ph: float, ph1: float,
                  Ymax: float, l: float, Set: list) -> dict:
    """
    Extend the growing chain by one segment.
    Corresponds to MATLAB GenerateNext.
    """
    N = Coord.shape[1]
    if phics[-1] != 0:
        phics_new = phics + [0.0]
        ll = int(2 + 2 * np.random.poisson((l - 2) / 2))
        XX = np.arange(1, ll + 1)
        YY = np.tan(ph) * ((-1.0)**(XX + N) - (-1.0)**N) / 2
        X  = XX + Coord[0, N - 1]
        Y  = YY + Coord[1, N - 1]
    else:
        phic = (-1.0)**N * ph1
        phics_new = phics + [phic]
        Tst = True
        while Tst:
            ll  = int(1 + 2 * np.random.poisson((l - 1) / 2))
            XX0 = np.arange(1, ll + 1)
            YY0 = np.tan(ph) * ((-1.0)**(XX0 + N) - (-1.0)**N) / 2
            XX  = XX0 * np.cos(phic) - YY0 * np.sin(phic)
            YY  = XX0 * np.sin(phic) + YY0 * np.cos(phic)
            X   = XX + Coord[0, N - 1]
            Y   = YY + Coord[1, N - 1]
            if np.max(np.abs(Y - 0.5)) < Ymax:
                Tst = False

    Coord_new = np.column_stack([Coord, np.row_stack([X, Y])])
    Set_new   = list(Set) + [ll]
    return {"Coord": Coord_new, "phics": phics_new, "Set": Set_new}


def generate_real_kinks_restr(ph: float, ph1: float,
                               Ymax: float, l: float, k: int) -> dict:
    """
    Generate a restricted random kink chain (bounded vertical displacement).
    Corresponds to MATLAB GenerateRealKinksRestr.
    """
    ll  = int(1 + np.random.poisson(l - 1))
    Set = [ll]
    phics = [0.0]
    XX = np.arange(ll)
    YY = np.tan(ph) * (1 + (-1.0)**np.arange(1, ll + 1)) / 2
    Coord = np.row_stack([XX, YY])

    for _ in range(k):
        z     = generate_next(Coord, phics, ph, ph1, Ymax, l, Set)
        Coord = z["Coord"]
        phics = z["phics"]
        Set   = z["Set"]

    return z


def generate_restr_kinks_coord(ph: float, ph1: float,
                                Ymax: float, l: float, k: int) -> dict:
    """
    Repeatedly call generate_real_kinks_restr until a valid closed chain
    is found, then extend with lead sites and build full coordinates.
    Corresponds to MATLAB GenerateRestrKinksCoord.
    """
    valid = False
    while not valid:
        yz   = generate_real_kinks_restr(ph, ph1, Ymax, l, k)
        Set  = np.array(yz["Set"])
        Summ = int(np.sum(Set[:-1]))
        N    = yz["Coord"].shape[1]
        if Summ < l * k:
            nn = 1 + (1 - (-1)**Summ) // 2     # 1-based parity index
            if np.abs(yz["Coord"][1, Summ] - yz["Coord"][1, nn - 1]) < 1e-10:
                valid = True

    Set      = list(Set)
    Set[0]  += 2
    if N % 2 == 0:
        Set[-1] += 3
    else:
        Set[-1] += 2

    CoordExt = generate_real_kinks_pos(np.array(Set), ph, ph1)
    return {"yz": yz, "SetExt": np.array(Set), "CoordExt": CoordExt}


# ---------------------------------------------------------------------------
# Random-walk chain generation
# ---------------------------------------------------------------------------

def generate_real_kinks_rw(k: int, l: float, ph1: float) -> dict:
    """
    Generate segment lengths and angles for a random-walk kink chain.
    k must be divisible by 4.
    Corresponds to MATLAB GenerateRealKinksRW.
    """
    valid = False
    while not valid:
        Set  = 1 + np.random.poisson(l - 1, size=k)
        if np.sum(Set) < k * l:
            Sums  = np.cumsum(Set)
            Signs = (-1.0)**Sums
            Phis  = np.concatenate([[0.0], np.cumsum(Signs) * ph1])
            if abs(Phis[-1]) < 1e-10:
                valid = True

    remainder = int(k * l - np.sum(Set) + 1)
    Set_full  = np.append(Set, remainder)
    SetExt    = Set_full.copy()
    SetExt[0]  += 2
    SetExt[-1] += 2

    return {"Set": Set_full, "Phis": Phis, "SetExt": SetExt}


def generate_real_kinks_rw_coord(k: int, l: float,
                                  ph: float, ph1: float) -> np.ndarray:
    """
    Generate full (2, N) coordinate array for a random-walk chain.
    Retries until the chain closes exactly, i.e. the last y-coordinate is
    exactly zero (to floating-point precision, < 1e-10).
    The y-coordinates are always exact multiples of tan(ph)/2, so zero is
    either hit exactly or not at all — this is a true closure condition,
    not a tolerance on a small residual.
    Corresponds to MATLAB GenerateRealKinksRWCoord.
    Returns CoordExt as (2, N) array.
    """
    valid = False
    while not valid:
        yzz   = generate_real_kinks_rw(k, l, ph1)
        Coord = generate_real_kinks_pos_rw(yzz["SetExt"], yzz["Phis"], ph)
        if abs(Coord[1, -1]) < 1e-10:
            valid = True
    return Coord
