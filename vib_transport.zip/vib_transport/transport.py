"""
transport.py  –  block extraction, self-energy, transmission coefficients
Translated from MATLAB by Claude (2026).
"""

import numpy as np
from .core import (spectrum_om, reg_spectr_q, g0_matr, gs)
from .geometry import (kinks_coord, kinks_coord_def,
                       hessian_rot_kink, hessian_rot_kink_def)


# ---------------------------------------------------------------------------
# Vectn / Vectntr  –  displacement amplitudes at integer sites
# ---------------------------------------------------------------------------

def vectn(A: float, B: float, ph: float, om: float,
          n: int, num: int, N: int) -> np.ndarray:
    """
    Displacement amplitude vector (7 components) for longitudinal incidence.
    num=1 longitudinal, num=2 transverse component.
    n = site index (negative = left lead, non-negative = right lead).
    Corresponds to MATLAB Vectn.
    """
    z   = spectrum_om(A, B, ph, om)
    q   = z.Wv
    Gam = z.Gam
    Vv  = np.zeros(7, dtype=complex)  # [inc, refl_l, refl_t, ev, tr_l, tr_t, ev]

    if n < 0:
        yz1  = reg_spectr_q( q[0], A, B, ph, n)
        yzr1 = reg_spectr_q(-q[0], A, B, ph, n)
        yzr2 = reg_spectr_q( q[2], A, B, ph, n)
        if Gam.real > 0:
            yzrev = reg_spectr_q(-1j*Gam, A, B, ph, n)
        else:
            yzrev = reg_spectr_q( 1j*Gam, A, B, ph, n)
        Vv[:4] = [yz1.V[num-1], yzr1.V[num-1], yzr2.V[num-1], yzrev.V[num-1]]
    else:
        yzt1  = reg_spectr_q(q[0], A, B, ph, n)
        yzt2  = reg_spectr_q(q[3], A, B, ph, n)
        if Gam.real > 0:
            yztev = reg_spectr_q( 1j*Gam, A, B, ph, n)
        else:
            yztev = reg_spectr_q(-1j*Gam, A, B, ph, n)
        Vv[4] = np.exp(1j*q[0]*(N-1)) * yzt1.V[num-1]
        Vv[5] = np.exp(1j*q[3]*(N-1)) * yzt2.V[num-1]
        Vv[6] = yztev.V[num-1]

    return Vv


def vectntr(A: float, B: float, ph1: float, om: float,
            n: int, num: int, N: int) -> np.ndarray:
    """
    Same as vectn but for transverse incidence.
    Corresponds to MATLAB Vectntr.
    """
    z   = spectrum_om(A, B, ph1, om)
    q   = z.Wv
    Gam = z.Gam
    Vv  = np.zeros(7, dtype=complex)

    if n < 0:
        yz1  = reg_spectr_q( q[3], A, B, ph1, n)
        yzr1 = reg_spectr_q(-q[0], A, B, ph1, n)
        yzr2 = reg_spectr_q( q[2], A, B, ph1, n)
        if Gam.real > 0:
            yzrev = reg_spectr_q(-1j*Gam, A, B, ph1, n)
        else:
            yzrev = reg_spectr_q( 1j*Gam, A, B, ph1, n)
        Vv[:4] = [yz1.V[num-1], yzr1.V[num-1], yzr2.V[num-1], yzrev.V[num-1]]
    else:
        yzt1  = reg_spectr_q(q[0], A, B, ph1, n)
        yzt2  = reg_spectr_q(q[3], A, B, ph1, n)
        if Gam.real > 0:
            yztev = reg_spectr_q( 1j*Gam, A, B, ph1, n)
        else:
            yztev = reg_spectr_q(-1j*Gam, A, B, ph1, n)
        Vv[4] = np.exp(1j*q[0]*(N-1)) * yzt1.V[num-1]
        Vv[5] = np.exp(1j*q[3]*(N-1)) * yzt2.V[num-1]
        Vv[6] = yztev.V[num-1]

    return Vv


# ---------------------------------------------------------------------------
# SelfEnerg
# ---------------------------------------------------------------------------

def self_energ(om: float, Vl: np.ndarray, Vr: np.ndarray,
               H: np.ndarray) -> dict:
    """
    Self-energy matrices Mll, Mlr, Mrr, Mrl from the leads.
    Corresponds to MATLAB SelfEnerg.
    """
    N  = H.shape[0] // 2
    n1 = np.array([1, 2, N+1, N+2])          # 1-based
    n2 = np.array([N-1, N, 2*N-1, 2*N])
    return {
        "Mll": Vl @ gs(n1, n1, H, om) @ Vl.T,
        "Mlr": Vl @ gs(n1, n2, H, om) @ Vr.T,
        "Mrr": Vr @ gs(n2, n2, H, om) @ Vr.T,
        "Mrl": Vr @ gs(n2, n1, H, om) @ Vl.T,
    }


# ---------------------------------------------------------------------------
# GetTrsl  –  transmission for longitudinal incidence
# ---------------------------------------------------------------------------

def get_trsl(N: int, A: float, B: float, ph: float,
             om: float, Sigm: dict) -> tuple:
    """
    Transmission/reflection for longitudinal (acoustic) incidence.
    Returns (Trl, info_dict).
    Corresponds to MATLAB GetTrsl.
    """
    # build displacement-amplitude vectors at boundary sites
    u11  = vectn(A, B, ph, om,  1, 1, N//2)
    u12  = vectn(A, B, ph, om,  1, 2, N//2)
    u21  = vectn(A, B, ph, om,  2, 1, N//2)
    u22  = vectn(A, B, ph, om,  2, 2, N//2)
    u31  = vectn(A, B, ph, om,  3, 1, N//2)
    u32  = vectn(A, B, ph, om,  3, 2, N//2)
    u41  = vectn(A, B, ph, om,  4, 1, N//2)
    un11 = vectn(A, B, ph, om, -1, 1, N//2)
    un12 = vectn(A, B, ph, om, -1, 2, N//2)
    un21 = vectn(A, B, ph, om, -2, 1, N//2)
    un22 = vectn(A, B, ph, om, -2, 2, N//2)
    un31 = vectn(A, B, ph, om, -3, 1, N//2)
    un32 = vectn(A, B, ph, om, -3, 2, N//2)
    un41 = vectn(A, B, ph, om, -4, 1, N//2)

    Ul = np.row_stack([un21, un11, un12])
    Ur = np.row_stack([u11,  u21,  u12])

    Deltal = Sigm["Mll"] @ Ul + Sigm["Mlr"] @ Ur
    Deltar = Sigm["Mrl"] @ Ul + Sigm["Mrr"] @ Ur

    Eqn21 = (-om**2*un21 + A*np.cos(ph)**2*(2*un21-un31-un11)
              + B*(2*un21-un41) + A*np.sin(2*ph)*(un32-un12)/2 + Deltal[0])
    Eqn11 = (-om**2*un11 + A*np.cos(ph)**2*(2*un11-un21)
              + B*(2*un11-un31) - A*np.sin(2*ph)*un22/2 + Deltal[1])
    Eqn12 = (-om**2*un12 + A*np.sin(ph)**2*(2*un12-un22)
              - A*np.sin(2*ph)*un21/2 + Deltal[2])

    Eq21  = (-om**2*u21 + A*np.cos(ph)**2*(2*u21-u31-u11)
              + B*(2*u21-u41) - A*np.sin(2*ph)*(u32-u12)/2 + Deltar[1])
    Eq11  = (-om**2*u11 + A*np.cos(ph)**2*(2*u11-u21)
              + B*(2*u11-u31) + A*np.sin(2*ph)*u22/2 + Deltar[0])
    Eq12  = (-om**2*u12 + A*np.sin(ph)**2*(2*u12-u22)
              + A*np.sin(2*ph)*u21/2 + Deltar[2])

    M = np.row_stack([Eqn21, Eqn11, Eqn12, Eq21, Eq11, Eq12])

    trs = np.linalg.solve(-M[:, 1:], M[:, 0])

    Sp1  = spectrum_om(A, B, ph, om)
    q    = Sp1.Wv
    Spq1 = reg_spectr_q(q[0], A, B, ph, 0)
    Spq2 = reg_spectr_q(q[2], A, B, ph, 0)
    v1   = abs(Spq1.vg)
    v2   = abs(Spq2.vg)

    TRs = np.abs(trs)**2
    TRs[1] *= v2 / v1
    TRs[4] *= v2 / v1

    Trl = TRs[3] + TRs[4]
    TR  = np.array([TRs[0], TRs[1], TRs[3], TRs[4]])

    return Trl, {"M": M, "TR": TR, "Check": TR.sum() - 1, "trs": trs}


# ---------------------------------------------------------------------------
# GetTrst  –  transmission for transverse incidence
# ---------------------------------------------------------------------------

def get_trst(N: int, A: float, B: float, ph: float,
             om: float, Sigm: dict) -> tuple:
    """
    Transmission/reflection for transverse (optical) incidence.
    Returns (Trt, info_dict).
    Corresponds to MATLAB GetTrst.
    """
    u11  = vectntr(A, B, ph, om,  1, 1, N//2)
    u12  = vectntr(A, B, ph, om,  1, 2, N//2)
    u21  = vectntr(A, B, ph, om,  2, 1, N//2)
    u22  = vectntr(A, B, ph, om,  2, 2, N//2)
    u31  = vectntr(A, B, ph, om,  3, 1, N//2)
    u32  = vectntr(A, B, ph, om,  3, 2, N//2)
    u41  = vectntr(A, B, ph, om,  4, 1, N//2)
    un11 = vectntr(A, B, ph, om, -1, 1, N//2)
    un12 = vectntr(A, B, ph, om, -1, 2, N//2)
    un21 = vectntr(A, B, ph, om, -2, 1, N//2)
    un22 = vectntr(A, B, ph, om, -2, 2, N//2)
    un31 = vectntr(A, B, ph, om, -3, 1, N//2)
    un32 = vectntr(A, B, ph, om, -3, 2, N//2)
    un41 = vectntr(A, B, ph, om, -4, 1, N//2)

    Ul = np.row_stack([un21, un11, un12])
    Ur = np.row_stack([u11,  u21,  u12])

    Deltal = Sigm["Mll"] @ Ul + Sigm["Mlr"] @ Ur
    Deltar = Sigm["Mrl"] @ Ul + Sigm["Mrr"] @ Ur

    Eqn21 = (-om**2*un21 + A*np.cos(ph)**2*(2*un21-un31-un11)
              + B*(2*un21-un41) + A*np.sin(2*ph)*(un32-un12)/2 + Deltal[0])
    Eqn11 = (-om**2*un11 + A*np.cos(ph)**2*(2*un11-un21)
              + B*(2*un11-un31) - A*np.sin(2*ph)*un22/2 + Deltal[1])
    Eqn12 = (-om**2*un12 + A*np.sin(ph)**2*(2*un12-un22)
              - A*np.sin(2*ph)*un21/2 + Deltal[2])

    Eq21  = (-om**2*u21 + A*np.cos(ph)**2*(2*u21-u31-u11)
              + B*(2*u21-u41) - A*np.sin(2*ph)*(u32-u12)/2 + Deltar[1])
    Eq11  = (-om**2*u11 + A*np.cos(ph)**2*(2*u11-u21)
              + B*(2*u11-u31) + A*np.sin(2*ph)*u22/2 + Deltar[0])
    Eq12  = (-om**2*u12 + A*np.sin(ph)**2*(2*u12-u22)
              + A*np.sin(2*ph)*u21/2 + Deltar[2])

    M   = np.row_stack([Eqn21, Eqn11, Eqn12, Eq21, Eq11, Eq12])
    trs = np.linalg.solve(-M[:, 1:], M[:, 0])

    Sp1  = spectrum_om(A, B, ph, om)
    q    = Sp1.Wv
    Spq1 = reg_spectr_q(q[0], A, B, ph, 0)
    Spq2 = reg_spectr_q(q[2], A, B, ph, 0)
    v1   = abs(Spq1.vg)
    v2   = abs(Spq2.vg)

    TRs      = np.abs(trs)**2
    TRs[0]  *= v1 / v2
    TRs[3]  *= v1 / v2

    TR  = np.array([TRs[0], TRs[1], TRs[3], TRs[4]])
    Trt = TRs[3] + TRs[4]

    return Trt, {"M": M, "TR": TR, "Check": TR.sum() - 1, "trs": trs}


# ---------------------------------------------------------------------------
# Transmission  –  top-level entry point
# ---------------------------------------------------------------------------

def transmission(om: float, Vl: np.ndarray, Vr: np.ndarray,
                 H: np.ndarray, A: float, B: float, ph: float) -> tuple:
    """
    Total transmission coefficient and per-channel breakdowns.
    Returns (T_total, Tst, Trl, Trt, z).
    Corresponds to MATLAB Transmission.
    """
    Sigm = self_energ(om, Vl, Vr, H)
    N    = H.shape[0]

    Trl, y1 = get_trsl(N, A, B, ph, om, Sigm)
    Trt, y2 = get_trst(N, A, B, ph, om, Sigm)

    z = {
        "TRL": y1["TR"][[2, 3, 0, 1]],
        "TRT": y2["TR"][[2, 3, 0, 1]],
    }
    T_total = Trl + Trt
    Tst     = np.array([y1["Check"], y2["Check"]])

    if (abs(y1["Check"]) > 0.1) or (abs(y2["Check"]) > 0.1):
        print("Warning: normalisation fails")

    return T_total, Tst, Trl, Trt, z


# ---------------------------------------------------------------------------
# BlocksCoordGenRot / BlocksCoordGenRotDef  –  block extraction
# ---------------------------------------------------------------------------

def blocks_coord_gen_rot(A: float, B: float, ph: float,
                          ph2: float, n: int) -> dict:
    """
    Generate kink geometry and extract coupling / on-site Hamiltonian blocks.
    Corresponds to MATLAB BlocksCoordGenRot.
    """
    from .geometry import kinks_coord
    print(n)

    Crd = kinks_coord(6, ph, ph2)
    Coordin = np.column_stack([Crd.x, Crd.y])   # (N_inner, 2)

    xm2 = Coordin[0, 0] - 2;   ym2 = Coordin[0, 1]
    xm1 = Coordin[0, 0] - 1;   ym1 = Coordin[0, 1] + np.tan(ph)
    x2  = Coordin[-1, 0] + 2*np.cos(ph2);  y2 = Coordin[-1, 1] + 2*np.sin(ph2)
    x1  = (Coordin[-1, 0] + np.cos(ph2) - np.tan(ph)*np.sin(ph2))
    y1  = (Coordin[-1, 1] + np.tan(ph)*np.cos(ph2) + np.sin(ph2))

    Coord = np.row_stack([[xm2, ym2], [xm1, ym1], Coordin,
                           [x1, y1], [x2, y2]])
    N = Coordin.shape[0] - 1

    yz = hessian_rot_kink(A, B, ph, ph2, n + 2)
    H  = yz["Hrot"]

    Sites     = list(range(2, 3 + N)) + list(range(N + 7, 2*N + 8))
    Sitesl    = [0, 1, N + 6]
    Sitesr    = [N + 3, N + 4, 2*N + 8]
    SitesInl  = [2, 3, N + 7, N + 8]
    SitesInr  = [N + 1, N + 2, 2*N + 6, 2*N + 7]
    SitesInTot = list(range(2, N + 3)) + list(range(N + 7, 2*N + 8))

    # convert to 0-based
    def s0(lst): return [i - 1 for i in lst] if isinstance(lst[0], int) and lst[0] > 0 else lst

    Sites      = [i - 1 for i in [j+1 for j in Sites]]      # already 0-based from range
    # rebuild cleanly in 1-based then subtract 1
    Sites      = list(range(3-1, 3+N)) + list(range(N+8-1, 2*N+8))
    Sitesl     = [0, 1, N+6]
    Sitesr     = [N+3, N+4, 2*N+8]
    SitesInl   = [2, 3, N+7, N+8]
    SitesInr   = [N+1, N+2, 2*N+6, 2*N+7]
    SitesInTot = list(range(2, N+3)) + list(range(N+7, 2*N+8))

    return {
        "Hin":  H[np.ix_(Sites, Sites)],
        "Vl":   H[np.ix_(Sitesl, SitesInl)],
        "Vlt":  H[np.ix_(Sitesl, SitesInTot)],
        "Vr":   H[np.ix_(Sitesr, SitesInr)],
        "Vrt":  H[np.ix_(Sitesr, SitesInTot)],
        "Ht":   H,
        "Coord": Coord,
    }


def blocks_coord_gen_rot_def(A: float, B: float, ph: float,
                              ph1: float, n: int,
                              dx: float, dy: float) -> dict:
    """
    Same as blocks_coord_gen_rot but with a displaced junction atom.
    Corresponds to MATLAB BlocksCoordGenRotDef.
    """
    print(n)
    yz = hessian_rot_kink_def(A, B, ph, ph1, n + 2, dx, dy)
    N  = 2 * n
    H  = yz["Hrot"]
    print(H.shape)

    Sites      = list(range(2, N+3)) + list(range(N+7, 2*N+8))
    Sitesl     = [0, 1, N+6]
    Sitesr     = [N+3, N+4, 2*N+8]
    SitesInl   = [2, 3, N+7, N+8]
    SitesInr   = [N+1, N+2, 2*N+6, 2*N+7]
    SitesInTot = list(range(2, N+3)) + list(range(N+7, 2*N+8))

    Coord = yz["Coord"]
    Coord_arr = np.column_stack([Coord.x, Coord.y])

    return {
        "Hin":  H[np.ix_(Sites, Sites)],
        "Vl":   H[np.ix_(Sitesl, SitesInl)],
        "Vlt":  H[np.ix_(Sitesl, SitesInTot)],
        "Vr":   H[np.ix_(Sitesr, SitesInr)],
        "Vrt":  H[np.ix_(Sitesr, SitesInTot)],
        "Ht":   H,
        "Coord": Coord_arr,
    }


# ---------------------------------------------------------------------------
# TRGF  –  Green-function based transmission
# ---------------------------------------------------------------------------

def trgf(A: float, B: float, ph: float, om: float,
         VH: np.ndarray, nu: int) -> dict:
    """
    Transmission via full Green function method.
    Corresponds to MATLAB TRGF.
    """
    N = VH.shape[0] // 2

    Sp   = spectrum_om(A, B, ph, om)
    Spq  = reg_spectr_q(Sp.Wv[0], A, B, ph, 0)
    Spq2 = reg_spectr_q(Sp.Wv[3], A, B, ph, 0)
    if nu == 1:
        v1, v2 = Spq.vg, Spq2.vg
    else:
        v2, v1 = Spq.vg, Spq2.vg

    G0tot = g0_matr(np.arange(1, 2*N+1), np.arange(1, 2*N+1), N, 0, A, B, ph, om)
    G01   = g0_matr(np.arange(1, 2*N+1), np.arange(1, 2*N+1), N, 1, A, B, ph, om)
    G02   = g0_matr(np.arange(1, 2*N+1), np.arange(1, 2*N+1), N, 2, A, B, ph, om)

    PH = VH @ G0tot
    M  = np.linalg.solve(np.eye(VH.shape[0]) + VH @ G0tot, PH)
    G1 = G01 - G01 @ M
    G2 = G02 - G02 @ M

    # incident wave amplitudes
    Sp   = spectrum_om(A, B, ph, om)
    Spq1 = reg_spectr_q(Sp.Wv[0], A, B, ph, 0)
    Spq2 = reg_spectr_q(Sp.Wv[3], A, B, ph, 0)

    ns = np.arange(N)
    u1 = np.zeros(2*N, dtype=complex)
    u1[:N]    = np.exp(1j*Sp.Wv[0]*ns) * Spq1.V[0]
    u1[N:2*N] = -np.exp(1j*Sp.Wv[0]*ns) * Spq1.V[1] * (-1)**np.arange(1, N+1)

    u2 = np.zeros(2*N, dtype=complex)
    u2[:N]    = np.exp(1j*Sp.Wv[3]*ns) * Spq2.V[0]
    u2[N:2*N] = -np.exp(1j*Sp.Wv[3]*ns) * Spq2.V[1] * (-1)**np.arange(1, N+1)

    VV1 = VH @ u1
    VV2 = VH @ u2

    # indices (0-based): N-1, 2N-1 and 0, N
    iN  = N - 1;  i2N = 2*N - 1
    i0  = 0;      iN1 = N

    T11 = np.linalg.norm(np.array([u1[iN],  u1[i2N]])  - G1[[iN, i2N], :] @ VV1)**2
    T21 = np.linalg.norm(G2[[iN, i2N], :] @ VV1)**2 * abs(v2/v1)
    R11 = np.linalg.norm(G1[[i0, iN1], :] @ VV1)**2
    R21 = np.linalg.norm(G2[[i0, iN1], :] @ VV1)**2 * abs(v2/v1)

    T12 = np.linalg.norm(G1[[iN, i2N], :] @ VV2)**2 * abs(v1/v2)
    T22 = np.linalg.norm(np.array([u2[iN],  u2[i2N]])  - G2[[iN, i2N], :] @ VV2)**2
    R12 = np.linalg.norm(G1[[i0, iN1], :] @ VV2)**2 * abs(v1/v2)
    R22 = np.linalg.norm(G2[[i0, iN1], :] @ VV2)**2

    return {
        "T11": T11, "T21": T21, "R11": R11, "R21": R21,
        "T12": T12, "T22": T22, "R12": R12, "R22": R22,
        "TRl": np.array([T11, T21, R11, R21]),
        "TRt": np.array([T12, T22, R12, R22]),
        "G":   G0tot,
        "Matr2": np.eye(VH.shape[0]) + VH @ G0tot,
    }
