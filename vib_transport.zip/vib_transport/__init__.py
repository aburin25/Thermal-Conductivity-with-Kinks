"""
vib_transport  –  vibrational energy transport in 2D kink chains
Python translation of MATLAB codes by Claude (2026).

Public API
----------
Core (spectrum, Green functions):
    spectrum_om, reg_spectr_q, g0_vect, g0_matr, gs

Geometry (coordinates, rotation, Hessian):
    kinks_coord, kinks_coord_def, rot_matr
    hessian_2d_op, hessian_2d_op_def_a, hessian_2d_op_def_b
    hessian_rot_kink, hessian_rot_kink_def
    hessian_rot_kink_def_a, hessian_rot_kink_def_b

Transport (self-energy, transmission):
    vectn, vectntr, self_energ
    get_trsl, get_trst, transmission
    blocks_coord_gen_rot, blocks_coord_gen_rot_def
    trgf
"""

from .core import spectrum_om, reg_spectr_q, g0_vect, g0_matr, gs
from .geometry import (kinks_coord, kinks_coord_def, rot_matr,
                        hessian_2d_op, hessian_2d_op_def_a, hessian_2d_op_def_b,
                        hessian_rot_kink, hessian_rot_kink_def,
                        hessian_rot_kink_def_a, hessian_rot_kink_def_b)
from .transport import (vectn, vectntr, self_energ,
                         get_trsl, get_trst, transmission,
                         blocks_coord_gen_rot, blocks_coord_gen_rot_def, trgf)
from .generate import (generate_restr_kinks_coord, generate_real_kinks_rw_coord)
from .thermal import (hessian_2d_op_def, blocks_coord_def,
                       om_max, transm_vect, transmission_scalar,
                       therm_cond_restr, therm_cond_rw)

__all__ = [
    # core
    "spectrum_om", "reg_spectr_q", "g0_vect", "g0_matr", "gs",
    # geometry
    "kinks_coord", "kinks_coord_def", "rot_matr",
    "hessian_2d_op", "hessian_2d_op_def_a", "hessian_2d_op_def_b",
    "hessian_rot_kink", "hessian_rot_kink_def",
    "hessian_rot_kink_def_a", "hessian_rot_kink_def_b",
    # transport (single kink)
    "vectn", "vectntr", "self_energ",
    "get_trsl", "get_trst", "transmission",
    "blocks_coord_gen_rot", "blocks_coord_gen_rot_def", "trgf",
    # coordinate generation
    "generate_restr_kinks_coord", "generate_real_kinks_rw_coord",
    # thermal conductivity
    "hessian_2d_op_def", "blocks_coord_def",
    "om_max", "transm_vect", "transmission_scalar",
    "therm_cond_restr", "therm_cond_rw",
]
