"""
example.py  –  quick smoke-test / usage demonstration
Run from the parent directory of vib_transport/:
    python -m vib_transport.example
"""

import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from vib_transport import (spectrum_om, reg_spectr_q,
                             hessian_rot_kink, kinks_coord,
                             transmission, self_energ)

# ── parameters ──────────────────────────────────────────────────────────────
A  = 4.0        # NN spring constant
B  = 1.0        # NNN spring constant
ph = np.pi / 6  # chain tilt angle
n  = 4          # kink half-length

# ── 1. Dispersion relation at a test frequency ───────────────────────────────
om = 1.5
Sp = spectrum_om(A, B, ph, om)
print("Wavevectors q:", np.round(Sp.Wv, 6))
print("Evanescent decay Γ:", np.round(Sp.Gam, 6))

RS = reg_spectr_q(Sp.Wv[0], A, B, ph, 0)
print(f"Group velocity at q1: {RS.vg:.6f}")
print(f"Eigenvector check: |ch1|={abs(RS.ch1):.2e}  |ch2|={abs(RS.ch2):.2e}")

# ── 2. Kink geometry and rotated Hessian ────────────────────────────────────
ph1 = np.pi / 4
yz  = hessian_rot_kink(A, B, ph, ph1, n)
print(f"\nHessian size: {yz['Hrot'].shape}")
eigs = np.linalg.eigvalsh(yz["Hstr"])
print(f"Min eigenvalue of straight-chain Hessian: {eigs[0]:.6f}  (should be ≈ 0)")

# ── 3. Geometry visualisation (requires matplotlib) ─────────────────────────
try:
    import matplotlib.pyplot as plt
    Crd = kinks_coord(n, ph, ph1)
    plt.figure(figsize=(8, 4))
    plt.plot(Crd.x, Crd.y, 'o-', ms=8)
    plt.axis("equal")
    plt.title(f"Kink chain  n={n}  φ={np.degrees(ph):.0f}°  φ₁={np.degrees(ph1):.0f}°")
    plt.xlabel("x"); plt.ylabel("y")
    plt.tight_layout()
    plt.savefig("kink_geometry.png", dpi=120)
    print("\nKink geometry saved to kink_geometry.png")
except ImportError:
    print("\n(matplotlib not available – skipping geometry plot)")

print("\nAll checks passed.")
