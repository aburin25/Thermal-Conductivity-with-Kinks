"""
geometry.py  –  kink coordinates, rotation matrices, Hessian builders
Translated from MATLAB by Claude (2026).
"""

import numpy as np
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# KinksCoord / KinksCoordDef
# ---------------------------------------------------------------------------

@dataclass
class KinkCoord:
    x: np.ndarray
    y: np.ndarray


def kinks_coord(n: int, ph: float, ph1: float) -> KinkCoord:
    """
    2D kink chain coordinates (undeformed).
    Corresponds to MATLAB KinksCoord.
    """
    xl  = np.arange(-n, 1, dtype=float)
    yl  = np.tan(ph) * (1 - (-1)**xl) / 2

    xr0 = np.arange(1, n + 1, dtype=float)
    yr0 = np.tan(ph) * (1 - (-1)**xr0) / 2
    xr  = xr0 * np.cos(ph1) - yr0 * np.sin(ph1)
    yr  = xr0 * np.sin(ph1) + yr0 * np.cos(ph1)

    return KinkCoord(x=np.concatenate([xl, xr]),
                     y=np.concatenate([yl, yr]))


def kinks_coord_def(n: int, ph: float, ph1: float,
                    dx: float, dy: float) -> KinkCoord:
    """
    Kink chain with a single-atom displacement at the kink site.
    Corresponds to MATLAB KinksCoordDef.
    """
    xl = np.arange(-n, 1, dtype=float)
    yl = np.tan(ph) * (1 - (-1)**xl) / 2

    xr0 = np.arange(1, n + 1, dtype=float)
    yr0 = np.tan(ph) * (1 - (-1)**xr0) / 2
    xr  = xr0 * np.cos(ph1) - yr0 * np.sin(ph1)
    yr  = xr0 * np.sin(ph1) + yr0 * np.cos(ph1)

    # shift the junction atom (last element of xl/yl)
    xl[-1] += dx
    yl[-1] += dy

    return KinkCoord(x=np.concatenate([xl, xr]),
                     y=np.concatenate([yl, yr]))


# ---------------------------------------------------------------------------
# RotMatr
# ---------------------------------------------------------------------------

def rot_matr(phs: np.ndarray, ns: np.ndarray, N: int) -> np.ndarray:
    """
    Block-diagonal rotation matrix for a 2N×2N displacement vector.
    Sites ns (1-based) are rotated by angles phs; all others are identity.
    Corresponds to MATLAB RotMatr.
    """
    Matr = np.eye(2 * N, dtype=float)
    for ii, site in enumerate(ns):
        s = site - 1          # 0-based
        c, ss = np.cos(phs[ii]), np.sin(phs[ii])
        Matr[np.ix_([s, s + N], [s, s + N])] = np.array([[c, ss], [-ss, c]])
    return Matr


# ---------------------------------------------------------------------------
# HessMatrAdd2D  –  bond contribution to the Hessian
# ---------------------------------------------------------------------------

def hess_matr_add_2d(r1: np.ndarray, r2: np.ndarray, A: float) -> np.ndarray:
    """
    4×4 Hessian contribution for the pair (r1, r2) with spring constant A.
    Ordering: [x1, y1, x2, y2].
    Corresponds to MATLAB HessMatrAdd2D.
    """
    Diff = (r1 - r2) / np.linalg.norm(r1 - r2)
    dx, dy = Diff[0], Diff[1]
    HM = np.zeros((4, 4))
    # diagonal: self-terms
    HM[0, 0] += dx*dx;  HM[1, 1] += dy*dy
    HM[2, 2] += dx*dx;  HM[3, 3] += dy*dy
    # off-diagonal: cross-terms
    HM[0, 2] -= dx*dx;  HM[2, 0] -= dx*dx
    HM[1, 3] -= dy*dy;  HM[3, 1] -= dy*dy
    # mixed xy terms
    HM[0, 3] -= dx*dy;  HM[3, 0] -= dx*dy
    HM[0, 1] += dx*dy;  HM[1, 0] += dx*dy
    HM[1, 2] -= dx*dy;  HM[2, 1] -= dx*dy
    HM[2, 3] += dx*dy;  HM[3, 2] += dx*dy
    return A * HM


# ---------------------------------------------------------------------------
# Hessian2DOp  –  nearest + next-nearest neighbour Hessian
# ---------------------------------------------------------------------------

def hessian_2d_op(Coord: np.ndarray, A: float, B: float) -> dict:
    """
    Build the 2N×2N dynamical matrix for a chain with NN spring A
    and NNN spring B.
    Coord: (N,2) array of coordinates.
    Corresponds to MATLAB Hessian2DOp.
    """
    if Coord.shape[0] == 2:
        Coord = Coord.T
    N = Coord.shape[0]
    H = np.zeros((2 * N, 2 * N))

    for ii in range(N - 1):
        r1 = Coord[ii]
        r2 = Coord[ii + 1]
        idx = [ii, N + ii, ii + 1, N + ii + 1]
        Hl = hess_matr_add_2d(r1, r2, A)
        H[np.ix_(idx, idx)] += Hl

        if ii < N - 2:
            r3 = Coord[ii + 2]
            idx2 = [ii, N + ii, ii + 2, N + ii + 2]
            Hl = hess_matr_add_2d(r1, r3, B)
            H[np.ix_(idx2, idx2)] += Hl

    return {"H0": H}


def hessian_2d_op_def_a(Coord: np.ndarray, A: float, B: float,
                         A1: float, A2: float) -> dict:
    """
    Hessian with two modified NN spring constants near the kink.
    Corresponds to MATLAB Hessian2DOpDefA.
    """
    if Coord.shape[0] == 2:
        Coord = Coord.T
    N = Coord.shape[0]
    H = np.zeros((2 * N, 2 * N))
    kk = (N - 1) // 2
    AA = A * np.ones(N - 1)
    AA[kk - 1] = A1
    AA[kk]     = A2

    for ii in range(N - 1):
        r1 = Coord[ii]; r2 = Coord[ii + 1]
        idx = [ii, N + ii, ii + 1, N + ii + 1]
        H[np.ix_(idx, idx)] += hess_matr_add_2d(r1, r2, AA[ii])
        if ii < N - 2:
            r3 = Coord[ii + 2]
            idx2 = [ii, N + ii, ii + 2, N + ii + 2]
            H[np.ix_(idx2, idx2)] += hess_matr_add_2d(r1, r3, B)

    return {"H0": H}


def hessian_2d_op_def_b(Coord: np.ndarray, A: float, B: float,
                         B1: float, B2: float, B3: float) -> dict:
    """
    Hessian with three modified NNN spring constants near the kink.
    Corresponds to MATLAB Hessian2DOpDefB.
    """
    if Coord.shape[0] == 2:
        Coord = Coord.T
    N = Coord.shape[0]
    H = np.zeros((2 * N, 2 * N))
    kk = (N - 1) // 2
    BB = B * np.ones(N - 2)
    BB[kk - 2] = B1
    BB[kk - 1] = B2
    BB[kk]     = B3

    for ii in range(N - 1):
        r1 = Coord[ii]; r2 = Coord[ii + 1]
        idx = [ii, N + ii, ii + 1, N + ii + 1]
        H[np.ix_(idx, idx)] += hess_matr_add_2d(r1, r2, A)
        if ii < N - 2:
            r3 = Coord[ii + 2]
            idx2 = [ii, N + ii, ii + 2, N + ii + 2]
            H[np.ix_(idx2, idx2)] += hess_matr_add_2d(r1, r3, BB[ii])

    return {"H0": H}


# ---------------------------------------------------------------------------
# HessianRotKink family
# ---------------------------------------------------------------------------

def hessian_rot_kink(A: float, B: float, ph: float, ph1: float, n: int) -> dict:
    """
    Hessian in rotated frame for a kink chain of length 2n+1.
    Corresponds to MATLAB HessianRotKink.
    """
    N = 2 * n + 1
    Crd    = kinks_coord(n, ph, ph1)
    Crdstr = kinks_coord(n, ph, 0.0)
    Coord    = np.column_stack([Crd.x,    Crd.y])
    Coordstr = np.column_stack([Crdstr.x, Crdstr.y])

    H    = hessian_2d_op(Coord,    A, B)["H0"]
    Hstr = hessian_2d_op(Coordstr, A, B)["H0"]

    phs  = np.concatenate([[0.0], ph1 * np.ones(n)])
    ns   = np.arange(n + 1, 2 * n + 2)   # 1-based sites n+1 … 2n+1
    Matr  = rot_matr( phs, ns, N)
    MatrP = rot_matr(-phs, ns, N)

    Hrot = Matr @ H @ MatrP
    return {"H": H, "Hrot": Hrot, "Hstr": Hstr, "V": Hrot - Hstr}


def hessian_rot_kink_def(A: float, B: float, ph: float, ph1: float,
                          n: int, dx: float, dy: float) -> dict:
    """
    Same as hessian_rot_kink but with a displaced junction atom.
    Corresponds to MATLAB HessianRotKinkDef.
    """
    N = 2 * n + 1
    Crd    = kinks_coord_def(n, ph, ph1, dx, dy)
    Crdstr = kinks_coord(n, ph, 0.0)
    Coord    = np.column_stack([Crd.x,    Crd.y])
    Coordstr = np.column_stack([Crdstr.x, Crdstr.y])

    H    = hessian_2d_op(Coord,    A, B)["H0"]
    Hstr = hessian_2d_op(Coordstr, A, B)["H0"]

    phs  = np.concatenate([[0.0], ph1 * np.ones(n)])
    ns   = np.arange(n + 1, 2 * n + 2)
    Matr  = rot_matr( phs, ns, N)
    MatrP = rot_matr(-phs, ns, N)

    Hrot = Matr @ H @ MatrP
    return {"H": H, "Hrot": Hrot, "Hstr": Hstr, "V": Hrot - Hstr, "Coord": Crd}


def hessian_rot_kink_def_a(A: float, B: float, A1: float, A2: float,
                            ph: float, ph1: float, n: int) -> dict:
    """Corresponds to MATLAB HessianRotKinkDefA."""
    N = 2 * n + 1
    Crd    = kinks_coord(n, ph, ph1)
    Crdstr = kinks_coord(n, ph, 0.0)
    Coord    = np.column_stack([Crd.x,    Crd.y])
    Coordstr = np.column_stack([Crdstr.x, Crdstr.y])

    H    = hessian_2d_op_def_a(Coord, A, B, A1, A2)["H0"]
    Hstr = hessian_2d_op(Coordstr, A, B)["H0"]

    phs = np.concatenate([[ph1/2], ph1 * np.ones(n)])
    ns  = np.arange(n + 1, 2 * n + 2)
    Matr  = rot_matr( phs, ns, N)
    MatrP = rot_matr(-phs, ns, N)

    Hrot = Matr @ H @ MatrP
    return {"H": H, "Hrot": Hrot, "Hstr": Hstr, "V": Hrot - Hstr}


def hessian_rot_kink_def_b(A: float, B: float,
                            B1: float, B2: float, B3: float,
                            ph: float, ph1: float, n: int) -> dict:
    """Corresponds to MATLAB HessianRotKinkDefB."""
    N = 2 * n + 1
    Crd    = kinks_coord(n, ph, ph1)
    Crdstr = kinks_coord(n, ph, 0.0)
    Coord    = np.column_stack([Crd.x,    Crd.y])
    Coordstr = np.column_stack([Crdstr.x, Crdstr.y])

    H    = hessian_2d_op_def_b(Coord, A, B, B1, B2, B3)["H0"]
    Hstr = hessian_2d_op(Coordstr, A, B)["H0"]

    phs = np.concatenate([[ph1/2], ph1 * np.ones(n)])
    ns  = np.arange(n + 1, 2 * n + 2)
    Matr  = rot_matr( phs, ns, N)
    MatrP = rot_matr(-phs, ns, N)

    Hrot = Matr @ H @ MatrP
    return {"H": H, "Hrot": Hrot, "Hstr": Hstr, "V": Hrot - Hstr}
