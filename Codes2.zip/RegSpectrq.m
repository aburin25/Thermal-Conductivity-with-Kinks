function y=RegSpectrq(q, A, B, ph1, n)
    om2=A*(1-cos(q)*cos(2*ph1))+B*(1-cos(2*q))-sqrt((A*(cos(2*ph1)-cos(q))+B*(1-cos(2*q)))^2+A^2*(sin(q)*sin(2*ph1))^2);
    om2Der1=A*sin(q)*cos(2*ph1)+2*B*sin(2*q);
    om2Der2a=2*(A*(cos(2*ph1)-cos(q))+B*(1-cos(2*q)))*(A*sin(q)+2*B*sin(2*q))+2*A^2*sin(2*ph1)^2*sin(q)*cos(q); 
    om2Der3a=0.5*om2Der2a/sqrt((A*(cos(2*ph1)-cos(q))+B*(1-cos(2*q)))^2+A^2*(sin(q)*sin(2*ph1))^2); 
    OmDer2=0.5*(om2Der1-om2Der3a)/sqrt(om2); 
    om = sqrt(om2); 
    Bl1=-om2+2*A*(1-cos(q))*cos(ph1)^2+2*B*(1-cos(2*q)); 
    Bl2=1i*sin(q)*sin(2*ph1)*A; 
    v=[1; -Bl1/Bl2]/sqrt(1+abs(Bl1)^2/abs(Bl2)^2);
    vm2=[exp(-1i*2*q)*v(1) exp(-2*1i*q)*v(2)];
    vm1=[exp(-1i*q)*v(1) -exp(-1i*q)*v(2)];
    v1=[exp(1i*q)*v(1) -exp(1i*q)*v(2)];
    v2=[exp(1i*2*q)*v(1) exp(2*1i*q)*v(2)];
    Check1=-om^2*v(1)+A*cos(ph1)^2*(2*v(1)-v1(1)-vm1(1))+B*(2*v(1)-v2(1)-vm2(1))-A*sin(2*ph1)*(v1(2)-vm1(2))/2; 
    Check2=-om^2*v(2)+A*sin(ph1)^2*(2*v(2)-v1(2)-vm1(2))-A*sin(2*ph1)*(v1(1)-vm1(1))/2; 
    y.om=om; 
    vn=[exp(1i*q*n)*v(1) (-1)^n*exp(1i*q*n)*v(2)];
    y.ch1=Check1; 
    y.ch2=Check2;
    y.V=vn; 
    y.vg=OmDer2; 
end


% N=1000
% Coord3=GenerateKinks(N, k, 0, pi/6);
% H3=Hessian2DPer(Coord3, 4, 1);
% E3=sqrt(eig(H3));
% y=RegSpectr(2*pi*(1/2-1/N1), A, B, pi/6)
% 
% y =
% 
%    1.4246e-06
% E3(3)
% 
% ans =
% 
%    1.4241e-06
% q1=2*pi*(1/2-1/N1)
%  om=sqrt(A*(1-cos(q1)*cos(2*ph1))+B*(1-cos(2*q1))-sqrt((A*(cos(2*ph1)-cos(q1))+B*(1-cos(2*q1)))^2+A^2*(sin(q1)*sin(2*ph1))^2));
% Bl1=-om^2+2*A*(1-cos(q1))*cos(ph1)^2+2*B*(1-cos(2*q1))
% Bl1 =
%    12.0000
% Bl2=1i*sin(q1)*sin(2*ph1)*A
% Bl2 =   0.0000 + 0.0054i
% v=[1 Bl1/Bl2]/sqrt(1+Bl1^2/abs(Bl2)^2)
