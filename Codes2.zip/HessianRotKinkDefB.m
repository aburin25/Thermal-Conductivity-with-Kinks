function y=HessianRotKinkDefB(A, B, B1, B2, B3, ph, ph1, n)
N=2*n+1; 
Crd=KinksCoord(n, ph, ph1);
Crdstr=KinksCoord(n, ph, 0);
Coord=[Crd.x; Crd.y]; 
Coordstr=[Crdstr.x; Crdstr.y]; 
h=Hessian2DOpDefB(Coord, A, B, B1, B2, B3);
H=h.H0; 
hstr=Hessian2DOp(Coordstr, A, B);
Hstr=hstr.H0;
phs=[ph1/2 ph1*ones(1, n)]; 
Matr=RotMatr(phs, (n+1):(2*n+1), N); 
MatrPr=RotMatr(-phs, (n+1):(2*n+1), N);
y.H=H; 
y.Hrot=Matr*H*MatrPr;
y.Hstr=Hstr;
y.V=y.Hrot-Hstr; 
end