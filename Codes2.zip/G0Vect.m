function [G, y]=G0Vect(m, n, alph, bet, A, B, ph, om)
if size(m, 1)==1
    m=m';
end
if size(n, 2)==1
    n=n';
end
% get q's 
Sp=SpectrumOm(A, B, ph, om);
q1=Sp.Wv(1); q2=Sp.Wv(4); Gamm=sign(real(Sp.Gam))*Sp.Gam; 
RS=RegSpectrq(q1, A, B, ph, 0); 
V1pl=conj(RS.V'); v1=RS.vg; V1min=RS.V'; 
RS=RegSpectrq(q2, A, B, ph, 0); 
V2pl=conj(RS.V'); v2=RS.vg; V2min=RS.V';
RS=RegSpectrq(i*Gamm, A, B, ph, 0); RS1=RegSpectrq(-i*Gamm, A, B, ph, 0); 
Vgampl=conj(RS.V'); vgam=RS.vg; Vgammin=conj(RS1.V'); 
%G0=0;
G01=exp(i*q1*abs(m-n)).*(V1pl(alph)*V1min(bet)*(1+sign(m-n))/2+V1pl(bet)*V1min(alph)*(1-sign(m-n))/2)/(i*2*v1*om); 
G02=exp(i*q2*abs(m-n)).*(V2pl(alph)*V2min(bet)*(1+sign(m-n))/2+V2pl(bet)*V2min(alph)*(1-sign(m-n))/2)/(i*2*v2*om); 
G03=exp(-Gamm*abs(m-n)).*(Vgampl(alph)*Vgammin(bet)*(1+sign(m-n))/2+Vgampl(bet)*Vgammin(alph)*(1-sign(m-n))/2)/(2*i*vgam*om*(Vgammin(1)^2-Vgammin(2)^2));
y.G01=G01.*(-1).^((alph-1)*(m-1)+(bet-1)*n+bet);
y.G02=G02.*(-1).^((alph-1)*(m-1)+(bet-1)*n+bet);
y.G03=G03.*(-1).^((alph-1)*(m-1)+(bet-1)*n+bet);
%yz=G0Coefs(n, bet, A, B, ph, om); Coefs=yz.Coefs; 
%y.G=Coefs(1)*y.G01+Coefs(2)*y.G02+Coefs(3)*y.G03; 
% get e's
% get vq's
G=y.G01+y.G02+y.G03; 
end
%(-om^2+2*A*cos(ph)^2+2*B)*G(n)-A*cos(ph)^2*(G(n-1)+G(n+1))-B*(G(n-2)+G(n+2))-(-1)^n*A*cos(ph)*sin(ph)*(G(N/2+n-1)-G(N/2+n+1))