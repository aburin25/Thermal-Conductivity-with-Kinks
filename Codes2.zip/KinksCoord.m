function y=KinksCoord(n, ph, ph1)
xl=(-n):0; yl=tan(ph)*(1-(-1).^xl)/2; 
xr0=1:n; yr0=tan(ph)*(1-(-1).^xr0)/2;
xr=xr0*cos(ph1)-yr0*sin(ph1); yr=xr0*sin(ph1)+yr0*cos(ph1);
y.x=[xl xr]; y.y=[yl yr];
%plot(y.x, y.y); axis equal; 
end