function y=RotMatr(phs, ns, N)
Matr=eye(2*N, 2*N);
for ii=1:numel(ns)
    Matr([ns(ii) ns(ii)+N], [ns(ii) ns(ii)+N])=[cos(phs(ii)) sin(phs(ii));  -sin(phs(ii)) cos(phs(ii))];
end
y=Matr;
end