function y=TRGF(A, B, ph, om, VH, nu)
    % G011 (l, t) 
    N=size(VH, 1)/2; 
    %Matr0=G0Matr([2 N+2], [1 1+N], N, nu, A, B, ph, om); 
    %NormInc=sum(sum(abs(Matr0.^2))); % amplitude of incident wave
    % G0(1, :), G0(:, end) end projected, then not
    %MatrInc=G0Matr(1:(2*N), [1 N+1], N, nu, A, B, ph, om);
    %Matr0TR=G0Matr([N 2*N], 1:(2*N), N, 3-nu, A, B, ph, om);
    %Matr0R=G0Matr([2 N+2], 1:(2*N), N, nu, A, B, ph, om);
    % Get V, find on -zero rows-columns 
    %nums=find(sum(abs(VH), 2)~=0);
    %VHpr=VH(nums, nums);
    %G0pr=G0Matr(nums, nums, N, 0, A, B, ph, om);
    %Sigma=(eye(size(G0pr, 1))+VHpr*G0pr)^(-1);
    %SigmaFull1=zeros(2*N, 2*N); 
    %SigmaFull1(nums, nums)=Sigma; 
    %G0Full=G0Matr(1:(2*N), 1:(2*N), N, 0, A, B, ph, om);
    %SigmaFull=(eye(2*N)+VH*G0Full)^(-1);
    %SigmaFull=eye(2*N); 
    % Gl, Gt 2, end 
    %GTr1=-G0Matr([N 2*N], 1:(2*N), N, nu, A, B, ph, om)*SigmaFull*VH*MatrInc+G0Matr([N 2*N], [1 N+1], N, nu, A, B, ph, om); 
    %GTr2=-G0Matr([N 2*N], 1:(2*N), N, 3-nu, A, B, ph, om)*SigmaFull*VH*MatrInc;
    %GR1=-G0Matr([1 N+1], 1:(2*N), N, nu, A, B, ph, om)*SigmaFull*VH*MatrInc; 
    %GR2=-G0Matr([1 N+1], 1:(2*N), N, 3-nu, A, B, ph, om)*SigmaFull*VH*MatrInc;
    Sp=SpectrumOm(A, B, ph, om); 
    Spq=RegSpectrq(Sp.Wv(1), A, B, ph, 0); Spq2=RegSpectrq(Sp.Wv(4), A, B, ph, 0);
    if nu==1
        v1=Spq.vg; v2=Spq2.vg; 
    else
        v2=Spq.vg; v1=Spq2.vg; 
    end
    % y.R1=sum(sum(abs(GR1)^2))/NormInc; 
    % y.T1=sum(sum(abs(GTr1)^2))/NormInc; 
    % y.R2=v2/v1*sum(sum(abs(GR2)^2))/NormInc;
    % y.T2=v2/v1*sum(sum(abs(GTr2)^2))/NormInc;
    %y.vg=[v1 v2]; 
    %G0=G0Matr(1:(2*N), [5 5+N], N, 0, A, B, ph, om);
    G0tot=G0Matr(1:(2*N), 1:(2*N), N, 0, A, B, ph, om);
    G01=G0Matr(1:(2*N), 1:(2*N), N, 1, A, B, ph, om);
    G02=G0Matr(1:(2*N), 1:(2*N), N, 2, A, B, ph, om);
    %G0a=G0Matr(1:(2*N), [5 5+N], N, 1, A, B, ph, om);
    %G=G0tot-G0tot*(eye(size(VH, 1))+VH*G0tot)^(-1)*VH*G0tot; 
    PH=VH*G0tot; 
    M=(eye(size(VH, 1))+VH*G0tot)\PH; 
    G1=G01-G01*M; 
    G2=G02-G02*M; 
    %y.R2=sum(sum(abs(GR2)^2))/NormInc;
    %y.T2=sum(sum(abs(GTr2)^2))/NormInc;
    % RT
    % get V_inc 1, 2 
    Sp=SpectrumOm(A, B, ph, om);
    Spq1=RegSpectrq(Sp.Wv(1), A, B, ph, 0); 
    Spq2=RegSpectrq(Sp.Wv(4), A, B, ph, 0); 
    u1=zeros(2*N, 1);
    u1(1:N)=exp(i*Sp.Wv(1)*(0:(N-1)))*Spq1.V(1);
    u1((N+1):(2*N))=-exp(i*Sp.Wv(1)*(0:(N-1)))*Spq1.V(2).*(-1).^(1:N);
    u2=zeros(2*N, 1);
    u2(1:N)=exp(i*Sp.Wv(4)*(0:(N-1)))*Spq2.V(1);
    u2((N+1):(2*N))=-exp(i*Sp.Wv(4)*(0:(N-1)))*Spq2.V(2).*(-1).^(1:N);
    VV1=VH*u1; 
    VV2=VH*u2; 
    % Get G1, G2
    %G1=y.G1; G2=y.G2; 
    y.T11=norm([u1(N); u1(2*N)]-G1([N 2*N], :)*VV1)^2;
    y.T21=norm(G2([N 2*N], :)*VV1)^2*v2/v1;
    y.R11=norm(G1([1 N+1], :)*VV1)^2;
    y.R21=norm(G2([1 N+1], :)*VV1)^2*v2/v1;
    y.T12=norm(G1([N 2*N], :)*VV2)^2*v1/v2;
    y.T22=norm([u2(N); u2(2*N)]-G2([N 2*N], :)*VV2)^2;%*v2/v1;
    y.R12=norm(G1([1 N+1], :)*VV2)^2*v1/v2;
    y.R22=norm(G2([1 N+1], :)*VV2)^2;%*v2/v1;
    y.TRl=[y.T11;y.T21;y.R11; y.R21];
    y.TRt=[y.T12;y.T22;y.R12; y.R22];
    y.G=G0tot; 
    y.Matr2=eye(size(VH, 1))+VH*G0tot; 
    % Get T, R
%    y.u1=u1; 
%    y.u11=u1-y.G*VH*u1; 
end