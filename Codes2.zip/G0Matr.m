function G=G0Matr(m, n, N, Typ, A, B, ph, om)
ms1=m(m<N+1); ms2=m(m>N); 
ns1=n(n<N+1); ns2=n(n>N); 
ms2=ms2-N; ns2=ns2-N; 
switch Typ 
    case 1
            [~, y]=G0Vect(ms1, ns1, 1, 1, A, B, ph, om); G11=y.G01; 
            [~, y]=G0Vect(ms1, ns2, 1, 2, A, B, ph, om); G12=y.G01; 
            [~, y]=G0Vect(ms2, ns1, 2, 1, A, B, ph, om); G21=y.G01; 
            [~, y]=G0Vect(ms2, ns2, 2, 2, A, B, ph, om); G22=y.G01; 
            Res=[G11 G12; G21 G22];
    case 2
            [~, y]=G0Vect(ms1, ns1, 1, 1, A, B, ph, om); G11=y.G02; 
            [~, y]=G0Vect(ms1, ns2, 1, 2, A, B, ph, om); G12=y.G02; 
            [~, y]=G0Vect(ms2, ns1, 2, 1, A, B, ph, om); G21=y.G02; 
            [~, y]=G0Vect(ms2, ns2, 2, 2, A, B, ph, om); G22=y.G02; 
            Res=[G11 G12; G21 G22];
    case 3
            [~, y]=G0Vect(ms1, ns1, 1, 1, A, B, ph, om); G11=y.G03; 
            [~, y]=G0Vect(ms1, ns2, 1, 2, A, B, ph, om); G12=y.G03; 
            [~, y]=G0Vect(ms2, ns1, 2, 1, A, B, ph, om); G21=y.G03; 
            [~, y]=G0Vect(ms2, ns2, 2, 2, A, B, ph, om); G22=y.G03; 
            Res=[G11 G12; G21 G22];
    otherwise
        Res= [G0Vect(ms1, ns1, 1, 1, A, B, ph, om) G0Vect(ms1, ns2, 1, 2, A, B, ph, om); G0Vect(ms2, ns1, 2, 1, A, B, ph, om) G0Vect(ms2, ns2, 2, 2, A, B, ph, om)];
end

G=Res; 
end
